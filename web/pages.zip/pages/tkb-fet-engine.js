/**
 * FET Timetable Engine for TKBCherry (Pure JS Local Implementation)
 * 
 * Implements the full core algorithms from FET (Free Educational Timetabling):
 * 1. Activity Difficulty Heuristic & Stable Sort (Most Difficult First, nIncompatible)
 * 2. Recursive Swapping with Backtracking & Tabu Search (randomSwap with max depth 16)
 * 3. MRG32k3a / Fisher-Yates slot permutation
 * 4. Multi-period block preservation with Dynamic Decomposition (tiết đôi / liên tiếp, tự phân rã khi cần để lấp kín 100%)
 * 5. Strict preservation of Fixed cells (tiết cố định) - preserves exact original object/styling
 * 6. Strict preservation of Prohibited / Off slots (tiết nghỉ của Lớp, Giáo viên, Phòng)
 * 7. Strict Subject Session Upper Limit (giới hạn tối đa số tiết/môn/buổi, ví dụ <= 2 hoặc <= 1)
 * 8. Multi-pass Ejection Chain & Cross-Class Relocation for 100% schedule completion
 */

(function(global){
  'use strict';

  const DAYS_LIST = ["thu2", "thu3", "thu4", "thu5", "thu6", "thu7"];
  const SESSIONS_LIST = ["sang", "chieu"];
  const PERIODS_PER_SESSION = 5;
  const SLOTS_PER_DAY = SESSIONS_LIST.length * PERIODS_PER_SESSION; // 10
  const TOTAL_SLOTS = DAYS_LIST.length * SLOTS_PER_DAY; // 60

  const INF = 1500000000;
  const INF2 = 2000000000;
  const MAX_RECURSION_LEVEL = 16;

  // PRNG (MRG32k3a equivalent for reproducible high quality randomization)
  class FetPRNG {
    constructor(seed = Date.now()){
      this.s10 = (seed & 0x7fffffff) || 12345;
      this.s11 = ((seed * 1103515245 + 12345) & 0x7fffffff) || 67890;
      this.s12 = ((seed * 214013 + 2531011) & 0x7fffffff) || 13579;
    }
    next(){
      const p = (this.s10 * 16807 + this.s11 * 48271 + this.s12 * 69621) % 2147483647;
      this.s10 = this.s11;
      this.s11 = this.s12;
      this.s12 = p;
      return (p & 0x7fffffff) / 2147483647;
    }
    nextInt(maxExclusive){
      if(maxExclusive <= 1) return 0;
      return Math.floor(this.next() * maxExclusive);
    }
    shuffle(array){
      for(let i = array.length - 1; i > 0; i--){
        const j = this.nextInt(i + 1);
        const temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }
      return array;
    }
  }

  function slotToDetails(slotIndex){
    const dayIdx = Math.floor(slotIndex / SLOTS_PER_DAY);
    const inDay = slotIndex % SLOTS_PER_DAY;
    const sessionIdx = Math.floor(inDay / PERIODS_PER_SESSION);
    const periodIdx = inDay % PERIODS_PER_SESSION;
    return {
      dayIdx,
      thu: DAYS_LIST[dayIdx] || "thu2",
      sessionIdx,
      buoi: SESSIONS_LIST[sessionIdx] || "sang",
      periodIdx
    };
  }

  function detailsToSlot(thu, buoi, periodIdx){
    const dayIdx = DAYS_LIST.indexOf(thu);
    const sessionIdx = SESSIONS_LIST.indexOf(buoi);
    if(dayIdx < 0 || sessionIdx < 0 || periodIdx < 0 || periodIdx >= PERIODS_PER_SESSION){
      return -1;
    }
    return dayIdx * SLOTS_PER_DAY + sessionIdx * PERIODS_PER_SESSION + periodIdx;
  }

  function parseTeacherList(raw){
    if(!raw) return [];
    if(Array.isArray(raw)) return raw.map(t => String(t || "").trim().toLowerCase()).filter(Boolean);
    return String(raw)
      .replace(/\r?\n/g, ",")
      .replace(/[;;]+/g, ",")
      .replace(/\s*[++]\s*/g, ",")
      .split(",")
      .map(t => t.trim().toLowerCase())
      .filter(Boolean);
  }

  class FetTimetableEngine {

    initLessonBlockRules(){
      this.classSubjectLessonBlocks = new Map();
      const constraints = this.data.tkbConstraints;
      if(!constraints || !constraints.subject) return;

      const classMap = new Map();
      const rawLop = Array.isArray(this.data.lop) ? this.data.lop : [];
      rawLop.forEach(l => {
        if(l.id) classMap.set(String(l.id).trim().toLowerCase(), String(l.id).trim());
        if(l.ten) {
          classMap.set(String(l.ten).trim().toLowerCase(), String(l.id || l.ten).trim());
          classMap.set(String(l.ten).trim(), String(l.id || l.ten).trim());
        }
      });

      Object.entries(constraints.subject).forEach(([sKey, subConf]) => {
        if(!subConf || !subConf.byClass) return;
        const sCanon = this.getCanonMonKey(sKey);

        Object.entries(subConf.byClass).forEach(([cId, cConf]) => {
          if(!cConf || !cConf.lessonBlocks) return;
          const classCanon = String(cId || "").trim();
          const targetCid = classMap.get(classCanon.toLowerCase()) || classCanon;

          Object.entries(cConf.lessonBlocks).forEach(([lenStr, bConf]) => {
            const len = parseInt(lenStr, 10);
            if(!len || len < 2) return;
            const min = bConf?.min != null ? Number(bConf.min) : 0;
            const max = bConf?.max != null ? Number(bConf.max) : Infinity;
            if(min > 0 || max < Infinity){
              const entry = { cid: targetCid, classCanon, sCanon, mon: sKey, len, min, max };
              this.classSubjectLessonBlocks.set(`${targetCid}|${sCanon}|${len}`, entry);
            }
          });
        });
      });
    }

    isLessonBlockSafe(...acts){
      if(!this.classSubjectLessonBlocks || this.classSubjectLessonBlocks.size === 0) return true;
      let targetClasses = null;
      if(acts && acts.length > 0){
        targetClasses = new Set(acts.map(a => a?.classId).filter(Boolean));
      }

      for(const [key, req] of this.classSubjectLessonBlocks.entries()){
        if(targetClasses && !targetClasses.has(req.cid) && !targetClasses.has(req.classCanon)) continue;
        const cGrid = this.classGrid.get(req.cid);
        if(!cGrid) continue;

        let blocks = 0;
        for(let d = 0; d < DAYS_LIST.length; d++){
          for(let b = 0; b < SESSIONS_LIST.length; b++){
            const sStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
            const idx = [];
            for(let p = 0; p < PERIODS_PER_SESSION; p++){
              const actId = cGrid[sStart + p];
              if(actId >= 0){
                const a = this.activities[actId];
                if(a && (a.canonKey === req.sCanon || this.getCanonMonKey(a.mon) === req.sCanon)){
                  idx.push(p + 1);
                }
              }else if(actId === -3){
                const fix = this.fixedSlots.get(`${req.cid}|${sStart + p}`);
                if(fix && fix.mon && this.getCanonMonKey(fix.mon) === req.sCanon){
                  idx.push(p + 1);
                }
              }
            }
            if(idx.length >= req.len){
              const sSet = new Set(idx);
              for(const i of idx){
                let ok = true;
                for(let k = 0; k < req.len; k++){
                  if(!sSet.has(i + k)) ok = false;
                }
                if(ok && !sSet.has(i - 1)) blocks++;
              }
            }
          }
        }
        if(blocks < req.min) return false;
        if(Number.isFinite(req.max) && blocks > req.max) return false;
      }
      return true;
    }

    evaluateLessonBlockViolations(){
      if(!this.classSubjectLessonBlocks || this.classSubjectLessonBlocks.size === 0) return 0;
      let violations = 0;
      for(const [key, req] of this.classSubjectLessonBlocks.entries()){
        const cGrid = this.classGrid.get(req.cid);
        if(!cGrid) continue;

        let blocks = 0;
        for(let d = 0; d < DAYS_LIST.length; d++){
          for(let b = 0; b < SESSIONS_LIST.length; b++){
            const sStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
            const idx = [];
            for(let p = 0; p < PERIODS_PER_SESSION; p++){
              const actId = cGrid[sStart + p];
              if(actId >= 0){
                const act = this.activities[actId];
                if(act && (act.canonKey === req.sCanon || this.getCanonMonKey(act.mon) === req.sCanon)){
                  idx.push(p + 1);
                }
              }else if(actId === -3){
                const fix = this.fixedSlots.get(`${req.cid}|${sStart + p}`);
                if(fix && fix.mon && this.getCanonMonKey(fix.mon) === req.sCanon){
                  idx.push(p + 1);
                }
              }
            }
            if(idx.length >= req.len){
              const sSet = new Set(idx);
              for(const i of idx){
                let ok = true;
                for(let k = 0; k < req.len; k++){
                  if(!sSet.has(i + k)) ok = false;
                }
                if(ok && !sSet.has(i - 1)) blocks++;
              }
            }
          }
        }
        if(blocks < req.min){
          violations += (req.min - blocks);
        }
      }
      return violations;
    }

    constructor(data, options = {}){
      this.data = data || {};
      this.options = options || {};
      this.rng = new FetPRNG(options.seed || Date.now());

      this.classes = [];
      this.activities = [];
      this.fixedSlots = new Map();    // key `${classId}|${slotIndex}` -> { mon, gv, room }
      this.fixedRawCells = new Map(); // key `${classId}|${slotIndex}` -> raw exact cell object
      this.offSlots = new Set();      // `${classId}|${slotIndex}`
      this.teacherOffSlots = new Set(); // `${teacherKey}|${slotIndex}`
      this.roomOffSlots = new Set();    // `${roomKey}|${slotIndex}`
      this.subjectOffSlots = new Set(); // `${subjectKey}|${slotIndex}`

      // State matrices
      this.classGrid = new Map();   // classId -> Array(60) of actId / -1 / -2(OFF) / -3(FIXED)
      this.teacherGrid = new Map(); // teacherKey -> Array(60) of actId / -1 / -2(OFF) / -3(FIXED)
      this.roomGrid = new Map();    // roomKey -> Array(60) of actId / -1 / -2(OFF) / -3(FIXED)
      this.actPlacement = [];       // actId -> slotIndex or -1

      // Tabu & Recursion stats
      this.tabuMap = new Map();
      this.currentStep = 0;
      this.nCalls = 0;
      this.limitCalls = 0;
      this.restoreStack = [];
      this.swappedInBranch = new Set();
    }

    // Parse data from TKBCherry DATA object
    init(){
      const data = this.data;
      const rawLop = Array.isArray(data.lop) ? data.lop : [];
      this.classes = rawLop.filter(l => l && (l.id || l.ten));

      const classMap = new Map();
      this.classes.forEach(l => {
        if(l.id) classMap.set(String(l.id).trim().toLowerCase(), String(l.id).trim());
        if(l.ten) {
          classMap.set(String(l.ten).trim().toLowerCase(), String(l.id || l.ten).trim());
          classMap.set(String(l.ten).trim(), String(l.id || l.ten).trim());
        }
      });

      this.initLessonBlockRules();

      // Build classes map
      this.classes.forEach(l => {
        const cid = String(l.id || "");
        this.classGrid.set(cid, new Array(TOTAL_SLOTS).fill(-1));
      });

      // 1. Scan current DATA.tkb for OFF and FIXED cells
      this.classes.forEach(l => {
        const cid = String(l.id || "");
        DAYS_LIST.forEach((thu, dIdx) => {
          SESSIONS_LIST.forEach((buoi, sIdx) => {
            const arr = data.tkb?.[cid]?.[thu]?.[buoi] || [];
            for(let ti = 0; ti < PERIODS_PER_SESSION; ti++){
              const slot = detailsToSlot(thu, buoi, ti);
              const cell = arr[ti];
              const key = `${cid}|${slot}`;

              if(this.isCellOff(cell)){
                this.offSlots.add(key);
                this.classGrid.get(cid)[slot] = -2; // -2 denotes OFF
              }else if(cell && this.isCellFixed(cell)){
                const mon = this.extractMon(cell);
                let gv = "";
                if(typeof cell === "object" && cell.gv){
                  gv = String(cell.gv).trim();
                }else if(typeof cell === "string" && cell.includes(" - ")){
                  gv = cell.split(" - ")[1].trim();
                }
                if(!gv){
                  gv = this.getTeacherForClassMon(l, mon);
                }
                const rm = this.getRoomForClassMon(l, mon);
                this.fixedSlots.set(key, { mon, gv, room: rm });
                this.fixedRawCells.set(key, cell); // Store exact original object
                this.classGrid.get(cid)[slot] = -3; // -3 denotes FIXED

                // Record teacher & room fixed occupancy
                const tList = parseTeacherList(gv);
                tList.forEach(t => {
                  if(!this.teacherGrid.has(t)) this.teacherGrid.set(t, new Array(TOTAL_SLOTS).fill(-1));
                  this.teacherGrid.get(t)[slot] = -3;
                });
                if(rm){
                  const rKey = rm.trim().toLowerCase();
                  if(!this.roomGrid.has(rKey)) this.roomGrid.set(rKey, new Array(TOTAL_SLOTS).fill(-1));
                  this.roomGrid.get(rKey)[slot] = -3;
                }
              }
            }
          });
        });
      });

      // 2. Scan external constraints (fixedOff from tkbConstraints)
      const classOffConstraints = data.tkbConstraints?.fixedOff?.class || data.lopNghi || {};
      Object.keys(classOffConstraints).forEach(cRaw => {
        const targetCid = classMap.get(String(cRaw).trim().toLowerCase()) || String(cRaw).trim();
        const slotsObj = classOffConstraints[cRaw] || {};
        Object.keys(slotsObj).forEach(k => {
          if(slotsObj[k]){
            const parts = k.replace(/_/g, "|").split("|");
            if(parts.length >= 3){
              const slot = detailsToSlot(parts[0], parts[1], Number(parts[2]));
              if(slot >= 0){
                this.offSlots.add(`${targetCid}|${slot}`);
                this.offSlots.add(`${cRaw}|${slot}`);
                if(this.classGrid.has(targetCid)) this.classGrid.get(targetCid)[slot] = -2;
                if(this.classGrid.has(cRaw)) this.classGrid.get(cRaw)[slot] = -2;
              }
            }
          }
        });
      });

      const teacherOffConstraints = data.tkbConstraints?.fixedOff?.teacher || data.teacherOff || data.gvNghi || {};
      Object.keys(teacherOffConstraints).forEach(tRaw => {
        const tKey = tRaw.trim().toLowerCase();
        const slotsObj = teacherOffConstraints[tRaw] || {};
        Object.keys(slotsObj).forEach(k => {
          if(slotsObj[k]){
            const parts = k.replace(/_/g, "|").split("|");
            if(parts.length >= 3){
              const slot = detailsToSlot(parts[0], parts[1], Number(parts[2]));
              if(slot >= 0){
                this.teacherOffSlots.add(`${tKey}|${slot}`);
                if(!this.teacherGrid.has(tKey)) this.teacherGrid.set(tKey, new Array(TOTAL_SLOTS).fill(-1));
                this.teacherGrid.get(tKey)[slot] = -2; // Teacher OFF
              }
            }
          }
        });
      });

      const roomOffConstraints = data.tkbConstraints?.fixedOff?.room || {};
      Object.keys(roomOffConstraints).forEach(rRaw => {
        const rKey = rRaw.trim().toLowerCase();
        const slotsObj = roomOffConstraints[rRaw] || {};
        Object.keys(slotsObj).forEach(k => {
          if(slotsObj[k]){
            const parts = k.replace(/_/g, "|").split("|");
            if(parts.length >= 3){
              const slot = detailsToSlot(parts[0], parts[1], Number(parts[2]));
              if(slot >= 0){
                this.roomOffSlots.add(`${rKey}|${slot}`);
                if(!this.roomGrid.has(rKey)) this.roomGrid.set(rKey, new Array(TOTAL_SLOTS).fill(-1));
                this.roomGrid.get(rKey)[slot] = -2;
              }
            }
          }
        });
      });

      const subjectOffConstraints = data.tkbConstraints?.fixedOff?.subject || {};
      Object.keys(subjectOffConstraints).forEach(sRaw => {
        const sCanon = this.getCanonMonKey(sRaw);
        const norm = this.normalizeMonName(sRaw);
        const slotsObj = subjectOffConstraints[sRaw] || {};
        Object.keys(slotsObj).forEach(k => {
          if(slotsObj[k]){
            const parts = k.replace(/_/g, "|").split("|");
            if(parts.length >= 3){
              const slot = detailsToSlot(parts[0], parts[1], Number(parts[2]));
              if(slot >= 0){
                this.subjectOffSlots.add(`${sCanon}|${slot}`);
                this.subjectOffSlots.add(`${norm}|${slot}`);
                this.subjectOffSlots.add(`${sRaw.trim().toLowerCase()}|${slot}`);
              }
            }
          }
        });
      });

      // 3. Build Activities from PCCM Matrix
      this.buildActivities();
    }

    isCellOff(cell){
      if(!cell) return false;
      if(cell === "OFF" || cell === "off") return true;
      if(typeof cell === "string" && (cell.trim().toLowerCase() === "nghi" || cell.trim().toLowerCase() === "off")) return true;
      if(typeof cell === "object" && (cell.off === true || cell.val === "OFF" || cell.mon === "OFF" || cell.off === 1 || cell.nghi === true)) return true;
      return false;
    }

    isCellFixed(cell){
      if(!cell) return false;
      if(typeof cell === "object" && (cell.fixed === true || cell.fixed === 1 || cell.cd === 1 || cell.cd === true || cell.codinh === true || cell.codinh === 1 || cell.isFixed === true || cell.locked === true)) return true;
      if(typeof cell === "string"){
        const s = cell.trim();
        if(s.startsWith("!") || s.endsWith("*") || s.includes("[fixed]") || s.startsWith("[cd]") || s.includes("(cố định)") || s.includes("(co dinh)")) return true;
      }
      return false;
    }

    extractTeacher(cell){
      if(!cell) return "";
      if(typeof cell === "object"){
        if(cell.gv) return String(cell.gv).trim();
        if(cell.teacher) return String(cell.teacher).trim();
        if(cell.mon && typeof cell.mon === "string" && cell.mon.includes(" - ")){
          return cell.mon.split(" - ").slice(1).join(" - ").trim();
        }
      }
      if(typeof cell === "string" && cell.includes(" - ")){
        return cell.split(" - ").slice(1).join(" - ").trim();
      }
      return "";
    }

    extractRoom(cell){
      if(!cell) return "";
      if(typeof cell === "object"){
        if(cell.room) return String(cell.room).trim();
        if(cell.phong) return String(cell.phong).trim();
      }
      return "";
    }

    extractMon(cell){
      if(!cell) return "";
      let m = "";
      if(typeof cell === "object") m = String(cell.mon || cell.val || cell.subject || "").trim();
      else m = String(cell).trim();
      if(m.includes(" - ")){
        m = m.split(" - ")[0].trim();
      }
      return m.replace(/^[!*]+|[!*]+$/g, "").replace(/\[fixed\]/gi, "").replace(/\[co_dinh\]/gi, "").trim();
    }

    normalizeMonName(name){
      if(!name) return "";
      let s = String(name).normalize('NFC').trim();
      if(s.includes(" - ")){
        s = s.split(" - ")[0].trim();
      }
      s = s.replace(/^[!*]+|[!*]+$/g, "").replace(/\[fixed\]/gi, "").replace(/\[co_dinh\]/gi, "").trim();
      s = s.replace(/\s+/g, " ");
      return s.toLowerCase();
    }

    getTeacherForClassMon(lop, mon){
      const data = this.data;
      if(!lop || !mon) return "";
      const classId = String(lop.id || "");
      const classCanon = lop.ten2 || lop.ten || classId;
      const key1 = `${classId}|${mon}`;
      const key2 = `${classCanon}|${mon}`;
      let val = data.pccmMatrix?.[key1] || data.pccmMatrix?.[key2] || data.tkbLessonTeachers?.[key1] || data.tkbLessonTeachers?.[key2] || "";
      if(!val){
        const norm = this.normalizeMonName(mon);
        const canon = this.getCanonMonKey(mon);
        for(const k of Object.keys(data.pccmMatrix || {})){
          if(k.startsWith(classId + "|") || k.startsWith(classCanon + "|")){
            const m = k.split("|").slice(1).join("|");
            if(this.normalizeMonName(m) === norm || (canon && this.getCanonMonKey(m) === canon)){
              val = data.pccmMatrix[k];
              break;
            }
          }
        }
      }
      return String(val || "").trim();
    }

    getRoomForClassMon(lop, mon){
      const data = this.data;
      if(!lop || !mon) return "";
      const classId = String(lop.id || "");
      const classCanon = lop.ten2 || lop.ten || classId;
      const key1 = `${classId}|${mon}`;
      const key2 = `${classCanon}|${mon}`;
      let val = data.pccmRoomMatrix?.[key1] || data.pccmRoomMatrix?.[key2] || data.tkbLessonRooms?.[key1] || data.tkbLessonRooms?.[key2] || "";
      if(!val){
        const norm = this.normalizeMonName(mon);
        for(const k of Object.keys(data.pccmRoomMatrix || {})){
          if(k.startsWith(classId + "|") || k.startsWith(classCanon + "|")){
            const m = k.split("|").slice(1).join("|");
            if(this.normalizeMonName(m) === norm){
              val = data.pccmRoomMatrix[k];
              break;
            }
          }
        }
      }
      return String(val || "").trim();
    }

    extractKhoiNumber(str){
      if(!str) return "";
      const m = String(str).match(/\d+/);
      return m ? m[0] : "";
    }

    getRequiredPeriods(lop, mon){
      const data = this.data;
      const classId = String(lop?.id || "");
      const classCanon = lop?.ten2 || lop?.ten || classId;
      const key1 = `${classId}|${mon}`;
      const key2 = `${classCanon}|${mon}`;
      let raw = data.pccmTietMatrix?.[key1] ?? data.pccmTietMatrix?.[key2];
      if(raw === undefined || raw === null || raw === ""){
        const norm = this.normalizeMonName(mon);
        for(const k of Object.keys(data.pccmTietMatrix || {})){
          if(k.startsWith(classId + "|") || k.startsWith(classCanon + "|")){
            const m = k.split("|").slice(1).join("|");
            if(this.normalizeMonName(m) === norm){
              raw = data.pccmTietMatrix[k];
              break;
            }
          }
        }
      }
      if(raw !== undefined && raw !== null && raw !== ""){
        const n = Number(raw);
        if(Number.isFinite(n) && n > 0) return Math.round(n);
      }

      const norm = this.normalizeMonName(mon);
      const classKhoi = this.extractKhoiNumber(lop?.khoi) || this.extractKhoiNumber(lop?.ten2) || this.extractKhoiNumber(lop?.ten);

      // 1. Check data.mon (per-grade configuration table: Khối, Tên, Số tiết, Giới hạn)
      const monListGrade = Array.isArray(data.mon) ? data.mon : [];
      if(classKhoi && monListGrade.length > 0){
        const match = monListGrade.find(m => {
          const mKhoi = this.extractKhoiNumber(m?.khoi);
          return mKhoi === classKhoi && (
            this.normalizeMonName(m?.ten) === norm ||
            this.normalizeMonName(m?.ma) === norm ||
            this.normalizeMonName(m?.id) === norm ||
            this.normalizeMonName(m?.mon) === norm
          );
        });
        if(match && Number(match.sotiet || match.tiet || match.required) > 0){
          return Math.round(Number(match.sotiet || match.tiet || match.required));
        }
      }

      // Check data.mon regardless of grade
      const matchGradeAny = monListGrade.find(m => (
        this.normalizeMonName(m?.ten) === norm ||
        this.normalizeMonName(m?.ma) === norm ||
        this.normalizeMonName(m?.id) === norm ||
        this.normalizeMonName(m?.mon) === norm
      ));
      if(matchGradeAny && Number(matchGradeAny.sotiet || matchGradeAny.tiet || matchGradeAny.required) > 0){
        return Math.round(Number(matchGradeAny.sotiet || matchGradeAny.tiet || matchGradeAny.required));
      }

      // 2. Check data.monhoc (global subject catalog)
      const monListGlobal = Array.isArray(data.monhoc) ? data.monhoc : [];
      const matchGlobal = monListGlobal.find(m => (
        this.normalizeMonName(m?.ten) === norm ||
        this.normalizeMonName(m?.ma) === norm ||
        this.normalizeMonName(m?.id) === norm ||
        this.normalizeMonName(m?.mon) === norm
      ));
      if(matchGlobal && Number(matchGlobal.sotiet || matchGlobal.tiet || matchGlobal.required) > 0){
        return Math.round(Number(matchGlobal.sotiet || matchGlobal.tiet || matchGlobal.required));
      }

      // If subject has a number suffix (like "HĐTN 1"), default is 1
      if(/\s+\d+$/.test(String(mon || "").trim())){
        return 1;
      }
      return 1; // Default fallback for any assigned PCCM subject
    }

    getSubjectSessionLimit(lop, mon){
      const data = this.data;
      if(!mon) return 2;
      const classId = String(lop?.id || "");
      const classCanon = lop?.ten2 || lop?.ten || classId;
      const k1 = `${classId}|${mon}`;
      const k2 = `${classCanon}|${mon}`;
      const raw = data.pccmGioihanMatrix?.[k1] ?? data.pccmGioihanMatrix?.[k2];
      if(raw !== undefined && raw !== null && raw !== ""){
        const val = Number(raw);
        if(Number.isFinite(val) && val > 0) return val;
      }

      const norm = this.normalizeMonName(mon);
      const classKhoi = this.extractKhoiNumber(lop?.khoi) || this.extractKhoiNumber(lop?.ten2) || this.extractKhoiNumber(lop?.ten);

      // Check data.mon with grade
      const monListGrade = Array.isArray(data.mon) ? data.mon : [];
      if(classKhoi && monListGrade.length > 0){
        const match = monListGrade.find(m => {
          const mKhoi = this.extractKhoiNumber(m?.khoi);
          return mKhoi === classKhoi && (
            this.normalizeMonName(m?.ten) === norm ||
            this.normalizeMonName(m?.ma) === norm ||
            this.normalizeMonName(m?.id) === norm ||
            this.normalizeMonName(m?.mon) === norm
          );
        });
        if(match && Number(match.gioihan) > 0) return Number(match.gioihan);
      }

      // Check data.mon regardless of grade
      const matchAny = monListGrade.find(m => (
        this.normalizeMonName(m?.ten) === norm ||
        this.normalizeMonName(m?.ma) === norm ||
        this.normalizeMonName(m?.id) === norm ||
        this.normalizeMonName(m?.mon) === norm
      ));
      if(matchAny && Number(matchAny.gioihan) > 0) return Number(matchAny.gioihan);

      // Check data.monhoc
      const monListGlobal = Array.isArray(data.monhoc) ? data.monhoc : [];
      const matchGlobal = monListGlobal.find(m => (
        this.normalizeMonName(m?.ten) === norm ||
        this.normalizeMonName(m?.ma) === norm ||
        this.normalizeMonName(m?.id) === norm ||
        this.normalizeMonName(m?.mon) === norm
      ));
      if(matchGlobal && Number(matchGlobal.gioihan) > 0) return Number(matchGlobal.gioihan);

      return 2; // Default upper bound per session is 2
    }

    removeDiacritics(str){
      if(!str) return "";
      return String(str)
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/đ/g, "d")
        .replace(/Đ/g, "D")
        .toLowerCase()
        .trim();
    }

    getCanonMonKey(mon){
      if(!mon) return "";
      let s = this.removeDiacritics(mon);
      s = s.replace(/\s+\d+$/, "").trim();
      s = s.replace(/\s+/g, " ");

      if(["chao co", "cc", "shdc", "sinh hoat duoi co", "shl", "sinh hoat lop", "sinh hoat", "tnhn", "hdtn", "hdtn,hn", "hdtn-hn", "hdtn/hn", "hoat dong trai nghiem", "hoat dong trai nghiem huong nghiep", "hoat dong trai nghiem va huong nghiep"].includes(s)){
        return "hdtn";
      }
      if(["lich su va dia ly", "lich su - dia ly", "lich su dia ly", "ls-dl", "ls&dl", "lsdl", "su dia", "sd"].includes(s)){
        return "lsdl";
      }
      if(["khoa hoc tu nhien", "khtn"].includes(s)){
        return "khtn";
      }
      if(["giao duc the chat", "the duc", "gdtc", "td"].includes(s)){
        return "gdtc";
      }
      if(["giao duc cong dan", "gdcd", "gd"].includes(s)){
        return "gdcd";
      }
      if(["giao duc dia phuong", "gddp", "noi dung giao duc dia phuong"].includes(s)){
        return "gddp";
      }
      if(["tin hoc", "tinqt", "tin"].includes(s)){
        return "tin";
      }
      if(["cong nghe", "cn"].includes(s)){
        return "cn";
      }
      if(["my thuat", "mi thuat", "mt"].includes(s)){
        return "mt";
      }
      if(["am nhac", "nhac", "an"].includes(s)){
        return "nhac";
      }
      if(["ngu van", "van", "va"].includes(s)){
        return "van";
      }
      if(["tieng anh", "ngoai ngu", "anh", "av"].includes(s)){
        return "anh";
      }
      if(["toan", "to"].includes(s)){
        return "toan";
      }
      return s;
    }

    isChaoCo(name){
      const n = this.normalizeMonName(name);
      return ["chào cờ", "chao co", "cc", "shdc", "sinh hoạt dưới cờ", "sinh hoat duoi co"].includes(n);
    }

    isSinhHoatLop(name){
      const n = this.normalizeMonName(name);
      return ["shl", "sinh hoạt lớp", "sinh hoat lop", "sinh hoạt", "sinh hoat"].includes(n);
    }

    resolveFixedSubjectToPccm(subjectMap, fixMon){
      const fixNorm = this.normalizeMonName(fixMon);
      if(subjectMap.has(fixNorm)) return subjectMap.get(fixNorm);

      if(this.isChaoCo(fixMon)){
        if(subjectMap.has(this.normalizeMonName("HĐTN 1"))) return subjectMap.get(this.normalizeMonName("HĐTN 1"));
        if(subjectMap.has(this.normalizeMonName("TNHN 1"))) return subjectMap.get(this.normalizeMonName("TNHN 1"));
        if(subjectMap.has(this.normalizeMonName("HĐTN"))) return subjectMap.get(this.normalizeMonName("HĐTN"));
        if(subjectMap.has(this.normalizeMonName("TNHN"))) return subjectMap.get(this.normalizeMonName("TNHN"));
      }

      if(this.isSinhHoatLop(fixMon)){
        if(subjectMap.has(this.normalizeMonName("HĐTN 3"))) return subjectMap.get(this.normalizeMonName("HĐTN 3"));
        if(subjectMap.has(this.normalizeMonName("HĐTN 2"))) return subjectMap.get(this.normalizeMonName("HĐTN 2"));
        if(subjectMap.has(this.normalizeMonName("TNHN 3"))) return subjectMap.get(this.normalizeMonName("TNHN 3"));
        if(subjectMap.has(this.normalizeMonName("TNHN 2"))) return subjectMap.get(this.normalizeMonName("TNHN 2"));
        if(subjectMap.has(this.normalizeMonName("HĐTN"))) return subjectMap.get(this.normalizeMonName("HĐTN"));
        if(subjectMap.has(this.normalizeMonName("TNHN"))) return subjectMap.get(this.normalizeMonName("TNHN"));
      }

      const fixCanon = this.getCanonMonKey(fixMon);
      for(const item of subjectMap.values()){
        if(item.canonKey === fixCanon && (item.remain > 0 || item.missing > 0)){
          return item;
        }
      }

      for(const item of subjectMap.values()){
        if(item.canonKey === fixCanon){
          return item;
        }
      }

      return null;
    }

    getShiftBlock(classId){
      if(this._classShiftBlockCache && this._classShiftBlockCache.has(classId)){
        return this._classShiftBlockCache.get(classId);
      }
      if(!this._classShiftBlockCache) this._classShiftBlockCache = new Map();

      const cGrid = this.classGrid.get(classId);
      if(!cGrid) return 'S';

      let offMorning = 0;
      let offAfternoon = 0;
      for(let d = 0; d < DAYS_LIST.length; d++){
        for(let p = 0; p < PERIODS_PER_SESSION; p++){
          const sMorning = d * SLOTS_PER_DAY + p;
          const sAfternoon = d * SLOTS_PER_DAY + 5 + p;
          if(cGrid[sMorning] === -2 || this.offSlots.has(`${classId}|${sMorning}`)) offMorning++;
          if(cGrid[sAfternoon] === -2 || this.offSlots.has(`${classId}|${sAfternoon}`)) offAfternoon++;
        }
      }
      const block = (offMorning < offAfternoon) ? 'S' : 'C';
      this._classShiftBlockCache.set(classId, block);
      return block;
    }

    classifySingleton(tKey, d, b, act){
      if(!act || !act.classId) return { type: 'STRUCTURAL', reason: 'no-activity' };
      const classId = act.classId;
      const mon = act.mon;
      const khoiLop = this.getShiftBlock(classId);
      const tGrid = this.teacherGrid.get(tKey);
      if(!tGrid) return { type: 'STRUCTURAL', reason: 'no-teacher-grid' };

      const candidates = [];
      for(let d2 = 0; d2 < DAYS_LIST.length; d2++){
        for(let b2 = 0; b2 < SESSIONS_LIST.length; b2++){
          if(d2 === d && b2 === b) continue;
          const sessKhoi = (b2 === 0) ? 'S' : 'C';
          if(sessKhoi !== khoiLop) continue;

          const sStart = d2 * SLOTS_PER_DAY + b2 * PERIODS_PER_SESSION;
          const taughtInSess = [];
          for(let p = 0; p < PERIODS_PER_SESSION; p++){
            const actId2 = tGrid[sStart + p];
            if(actId2 >= 0){
              const a2 = this.activities[actId2];
              if(a2) taughtInSess.push(a2);
            }
          }

          if(taughtInSess.length >= 1 && taughtInSess.length < 5){
            candidates.push({ d: d2, b: b2, acts: taughtInSess });
          }
        }
      }

      if(candidates.length === 0){
        return { type: 'STRUCTURAL', reason: 'no-other-session-same-shift-block' };
      }

      const monLimit = this.getSubjectSessionLimit(act.lop || { id: classId }, mon);

      for(const cand of candidates){
        if(cand.acts.some(a => a.classId !== classId)){
          return { type: 'FIXABLE', target: cand };
        }
        if(cand.acts.some(a => a.classId === classId && this.getCanonMonKey(a.mon) !== this.getCanonMonKey(mon))){
          return { type: 'FIXABLE', target: cand };
        }
        const sameSubjectCount = cand.acts.filter(a => a.classId === classId && this.getCanonMonKey(a.mon) === this.getCanonMonKey(mon)).length;
        if(sameSubjectCount < monLimit){
          return { type: 'FIXABLE', target: cand };
        }
      }

      return { type: 'STRUCTURAL', reason: 'same-subject-daily-cap-reached-everywhere' };
    }

    classifyAllSingletons(){
      const fixable = [];
      const structural = [];

      this.teacherGrid.forEach((grid, tKey) => {
        if(!tKey) return;
        for(let d = 0; d < DAYS_LIST.length; d++){
          for(let b = 0; b < SESSIONS_LIST.length; b++){
            const sStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
            const taught = [];
            for(let p = 0; p < PERIODS_PER_SESSION; p++){
              const actId = grid[sStart + p];
              if(actId >= 0){
                const act = this.activities[actId];
                if(act) taught.push({ slot: sStart + p, act });
              }else if(actId === -3){
                taught.push({ slot: sStart + p, act: { isFixed: true } });
              }
            }

            if(taught.length === 1){
              const item = taught[0];
              if(item.act.isFixed){
                structural.push({ teacher: tKey, day: DAYS_LIST[d], session: SESSIONS_LIST[b], reason: 'fixed-slot' });
              }else{
                const res = this.classifySingleton(tKey, d, b, item.act);
                if(res.type === 'FIXABLE'){
                  fixable.push({ teacher: tKey, day: d, buoi: b, slot: item.slot, act: item.act, target: res.target });
                }else{
                  structural.push({ teacher: tKey, day: DAYS_LIST[d], session: SESSIONS_LIST[b], reason: res.reason, classId: item.act.classId, mon: item.act.mon });
                }
              }
            }
          }
        }
      });

      return { fixable, structural };
    }

    getResidual2PeriodSessions(){
      const residuals = [];
      this.teacherGrid.forEach((grid, tKey) => {
        if(!tKey) return;
        for(let d = 0; d < DAYS_LIST.length; d++){
          for(let b = 0; b < SESSIONS_LIST.length; b++){
            const sStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
            const taught = [];
            for(let p = 0; p < PERIODS_PER_SESSION; p++){
              const s = sStart + p;
              if(grid[s] >= 0 || grid[s] === -3) taught.push({ slot: s, actId: grid[s] });
            }
            if(taught.length !== 2) continue;

            const classIds = taught
              .map(t => t.actId >= 0 ? this.activities[t.actId]?.classId : null)
              .filter(Boolean);
            const structurallyLocked = classIds.every(cid => {
              const shift = this.getShiftBlock(cid);
              return true;
            });

            residuals.push({
              teacher: tKey, day: DAYS_LIST[d], session: SESSIONS_LIST[b],
              reason: structurallyLocked ? "class-fixed-halfday-shift" : "algorithm-not-yet-resolved"
            });
          }
        }
      });
      return residuals;
    }

    buildActivities(){
      const data = this.data;
      const actList = [];
      let actCounter = 0;

      this.classes.forEach(lop => {
        const cid = String(lop.id || "");
        const classCanon = lop.ten2 || lop.ten || cid;
        const subjectMap = new Map(); // normKey -> { mon, canonKey, gv, room, required, maxSessionLimit }

        // 1. Scan PCCM Matrix and PCCM Tiet Matrix for explicit class assignments
        const checkKeys = Object.keys(data.pccmMatrix || {}).concat(Object.keys(data.pccmTietMatrix || {}));
        checkKeys.forEach(k => {
          if(k.startsWith(cid + "|") || k.startsWith(classCanon + "|")){
            const m = k.split("|").slice(1).join("|")?.trim();
            if(m){
              const mKey = this.normalizeMonName(m);
              if(!subjectMap.has(mKey)){
                const gv = this.getTeacherForClassMon(lop, m);
                const room = this.getRoomForClassMon(lop, m);
                const required = this.getRequiredPeriods(lop, m);
                const maxSessionLimit = this.getSubjectSessionLimit(lop, m);
                if(gv){
                  subjectMap.set(mKey, { mon: m, canonKey: this.getCanonMonKey(m), gv, room, required, maxSessionLimit, exactFixed: 0, remain: required });
                }
              }
            }
          }
        });

        // 2. Count already placed fixed periods with comprehensive alias & Chào cờ / SHL resolution
        for(let slot = 0; slot < TOTAL_SLOTS; slot++){
          const fix = this.fixedSlots.get(`${cid}|${slot}`);
          if(fix && fix.mon){
            const matched = this.resolveFixedSubjectToPccm(subjectMap, fix.mon);
            if(matched){
              matched.exactFixed = (matched.exactFixed || 0) + 1;
              matched.remain = Math.max(0, matched.required - matched.exactFixed);
            }
          }
        }

        // 3. Create movable activities for remaining periods (strictly never exceeding required)
        subjectMap.forEach((item, mKey) => {
          let remain = item.remain || 0;
          const gv = item.gv;
          const room = item.room;

          if(!gv) return;

          const sCanon = item.canonKey || this.getCanonMonKey(item.mon);
          const blockDurs = [];

          for(const len of [5, 4, 3, 2]){
            const req = this.classSubjectLessonBlocks ? (
              this.classSubjectLessonBlocks.get(`${cid}|${sCanon}|${len}`) ||
              this.classSubjectLessonBlocks.get(`${classCanon}|${sCanon}|${len}`)
            ) : null;
            const minReq = req ? req.min : 0;
            if(minReq > 0 && remain >= len){
              const count = Math.min(minReq, Math.floor(remain / len));
              for(let k = 0; k < count; k++){
                blockDurs.push(len);
                remain -= len;
              }
            }
          }

          for(const dur of blockDurs){
            actList.push({
              id: actCounter++,
              classId: cid,
              classCanon,
              lop,
              mon: item.mon,
              canonKey: sCanon,
              gv,
              room,
              duration: dur,
              isFixed: false,
              fixedSlot: -1,
              nIncompatible: 0
            });
          }

          while(remain > 0){
            let dur = 1;
            remain -= 1;

            actList.push({
              id: actCounter++,
              classId: cid,
              classCanon,
              lop,
              mon: item.mon,
              canonKey: sCanon,
              gv,
              room,
              duration: dur,
              isFixed: false,
              fixedSlot: -1,
              nIncompatible: 0
            });
          }
        });
      });

      this.activities = actList;
      this.actPlacement = new Array(actList.length).fill(-1);
    }

    computeDifficultiesAndSort(){
      const N = this.activities.length;
      const teacherActCount = new Map();
      const classActCount = new Map();

      this.activities.forEach(act => {
        if(act.gv){
          const tList = parseTeacherList(act.gv);
          tList.forEach(t => teacherActCount.set(t, (teacherActCount.get(t) || 0) + act.duration));
        }
        classActCount.set(act.classId, (classActCount.get(act.classId) || 0) + act.duration);
      });

      for(let i = 0; i < N; i++){
        const act = this.activities[i];
        let score = 0;
        if(act.gv){
          const tList = parseTeacherList(act.gv);
          tList.forEach(t => {
            score += (teacherActCount.get(t) || 0);
            const tGrid = this.teacherGrid.get(t);
            if(tGrid){
              for(let d = 0; d < DAYS_LIST.length; d++){
                for(let b = 0; b < SESSIONS_LIST.length; b++){
                  const sStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
                  let fCount = 0;
                  for(let p = 0; p < PERIODS_PER_SESSION; p++){
                    if(tGrid[sStart + p] === -3) fCount++;
                  }
                  if(fCount === 1) score += 300;
                }
              }
            }
          });
        }
        score += (classActCount.get(act.classId) || 0);

        let offCount = 0;
        for(let s = 0; s < TOTAL_SLOTS; s++){
          if(this.offSlots.has(`${act.classId}|${s}`) || this.fixedSlots.has(`${act.classId}|${s}`)){
            offCount++;
          }
        }
        score += offCount * 2;
        score *= act.duration;
        act.nIncompatible = score;
      }

      this.activities.sort((a, b) => {
        if(b.duration !== a.duration){
          return b.duration - a.duration;
        }
        return b.nIncompatible - a.nIncompatible;
      });

      this.activities.forEach((act, idx) => {
        act.id = idx;
      });
      this.actPlacement = new Array(this.activities.length).fill(-1);
    }

    placeActivityDirect(actId, slot){
      const act = this.activities[actId];
      if(!act) return;
      if(this.actPlacement[actId] >= 0 && this.actPlacement[actId] !== slot){
        this.unplaceActivity(actId);
      }
      this.actPlacement[actId] = slot;

      for(let d = 0; d < act.duration; d++){
        const s = slot + d;
        this.classGrid.get(act.classId)[s] = actId;

        if(act.gv){
          const tList = parseTeacherList(act.gv);
          tList.forEach(t => {
            if(!this.teacherGrid.has(t)) this.teacherGrid.set(t, new Array(TOTAL_SLOTS).fill(-1));
            this.teacherGrid.get(t)[s] = actId;
          });
        }
        if(act.room){
          const rKey = act.room.trim().toLowerCase();
          if(!this.roomGrid.has(rKey)) this.roomGrid.set(rKey, new Array(TOTAL_SLOTS).fill(-1));
          this.roomGrid.get(rKey)[s] = actId;
        }
      }
    }

    unplaceActivity(actId){
      const act = this.activities[actId];
      const oldSlot = this.actPlacement[actId];
      if(!act || oldSlot < 0) return;

      for(let d = 0; d < act.duration; d++){
        const s = oldSlot + d;
        if(this.classGrid.get(act.classId)[s] === actId){
          const cKey = `${act.classId}|${s}`;
          if(this.offSlots.has(cKey)) this.classGrid.get(act.classId)[s] = -2;
          else if(this.fixedSlots.has(cKey)) this.classGrid.get(act.classId)[s] = -3;
          else this.classGrid.get(act.classId)[s] = -1;
        }
        if(act.gv){
          const tList = parseTeacherList(act.gv);
          tList.forEach(t => {
            if(this.teacherGrid.has(t) && this.teacherGrid.get(t)[s] === actId){
              const tKey = `${t}|${s}`;
              if(this.teacherOffSlots.has(tKey)) this.teacherGrid.get(t)[s] = -2;
              else this.teacherGrid.get(t)[s] = -1;
            }
          });
        }
        if(act.room){
          const rKey = act.room.trim().toLowerCase();
          if(this.roomGrid.has(rKey) && this.roomGrid.get(rKey)[s] === actId){
            this.roomGrid.get(rKey)[s] = -1;
          }
        }
      }
      this.actPlacement[actId] = -1;
    }

    // Check conflicts, off slots, fixed cells, and session limits
    getConflictsForSlot(act, slot){
      const details = slotToDetails(slot);
      const endPeriod = details.periodIdx + act.duration - 1;
      if(endPeriod >= PERIODS_PER_SESSION){
        return { possible: false, conflicts: [] };
      }

      // Check class session preference (ca sáng/chiều)
      if(act.lop && act.lop.ca){
        const ca = String(act.lop.ca).trim().toLowerCase();
        if(ca === "sang" && details.buoi !== "sang") return { possible: false, conflicts: [] };
        if(ca === "chieu" && details.buoi !== "chieu") return { possible: false, conflicts: [] };
      }

      const conflictsSet = new Set();

      for(let d = 0; d < act.duration; d++){
        const s = slot + d;

        // Blocked by OFF or FIXED cell -> Impossible!
        if(this.offSlots.has(`${act.classId}|${s}`)) return { possible: false, conflicts: [] };
        if(this.fixedSlots.has(`${act.classId}|${s}`)) return { possible: false, conflicts: [] };
        if(this.subjectOffSlots && act.mon){
          if(this.subjectOffSlots.has(`${act.canonKey}|${s}`) || this.subjectOffSlots.has(`${this.normalizeMonName(act.mon)}|${s}`)){
            return { possible: false, conflicts: [] };
          }
        }

        const existingActId = this.classGrid.get(act.classId)[s];
        if(existingActId >= 0 && existingActId !== act.id){
          conflictsSet.add(existingActId);
        }

        // Teacher grid & off check
        if(act.gv){
          const tList = parseTeacherList(act.gv);
          for(const t of tList){
            if(this.teacherOffSlots.has(`${t}|${s}`)){
              return { possible: false, conflicts: [] }; // Teacher is off at this slot!
            }
            const tGrid = this.teacherGrid.get(t);
            if(tGrid){
              const tCell = tGrid[s];
              if(tCell === -3) return { possible: false, conflicts: [] }; // Teacher is fixed elsewhere
              if(tCell === -2) return { possible: false, conflicts: [] }; // Teacher OFF
              if(tCell >= 0 && tCell !== act.id){
                conflictsSet.add(tCell);
              }
            }
          }
        }

        // Room grid & off check
        if(act.room){
          const rKey = act.room.trim().toLowerCase();
          if(this.roomOffSlots.has(`${rKey}|${s}`)){
            return { possible: false, conflicts: [] }; // Room is off at this slot!
          }
          const rGrid = this.roomGrid.get(rKey);
          if(rGrid){
            const rCell = rGrid[s];
            if(rCell === -3 || rCell === -2) return { possible: false, conflicts: [] };
            if(rCell >= 0 && rCell !== act.id){
              conflictsSet.add(rCell);
            }
          }
        }
      }

      // Native FET Constraint: Teachers Max Consecutive Gap = 1 & Max Gaps Per Session = 1
      if(this.strictFetGaps && act.gv){
        const sessionStart = details.dayIdx * SLOTS_PER_DAY + details.sessionIdx * PERIODS_PER_SESSION;
        const tList = parseTeacherList(act.gv);
        for(const t of tList){
          const tGrid = this.teacherGrid.get(t);
          if(!tGrid) continue;

          const curP = [];
          for(let pi = 0; pi < PERIODS_PER_SESSION; pi++){
            const sCheck = sessionStart + pi;
            if(sCheck >= slot && sCheck < slot + act.duration){
              curP.push(pi);
            }else if((tGrid[sCheck] >= 0 && !conflictsSet.has(tGrid[sCheck])) || tGrid[sCheck] === -3){
              curP.push(pi);
            }
          }

          if(curP.length >= 2){
            curP.sort((a, b) => a - b);
            // 1. Số tiết nghỉ liên tục tối đa là 1 (FET Constraint: ConstraintTeachersMaxConsecutiveGaps = 1)
            for(let i = 0; i < curP.length - 1; i++){
              if(curP[i + 1] - curP[i] - 1 > 1){
                return { possible: false, conflicts: [] };
              }
            }
            // 2. Tối đa 1 buổi là 1 tiết nghỉ (FET Constraint: ConstraintTeachersMaxGapsPerMorningAndAfternoon = 1)
            const span = curP[curP.length - 1] - curP[0] + 1;
            if(span - curP.length > 1){
              return { possible: false, conflicts: [] };
            }
          }
        }
      }

      // Strict Session Subject Contiguity & Upper Limit Check
      // (Các tiết cùng môn học trong cùng 1 buổi BẮT BUỘC PHẢI XẾP LIỀN NHAU và không vượt quá giới hạn trên)
      const sessionStartSlot = details.dayIdx * SLOTS_PER_DAY + details.sessionIdx * PERIODS_PER_SESSION;
      const sessionEndSlot = sessionStartSlot + PERIODS_PER_SESSION;
      const maxPerSession = this.getSubjectSessionLimit(act.lop, act.mon);
      const actCanon = this.getCanonMonKey(act.mon);

      const subjectPeriods = [];
      for(let pi = 0; pi < PERIODS_PER_SESSION; pi++){
        const s = sessionStartSlot + pi;
        if(s >= slot && s < slot + act.duration){
          subjectPeriods.push(pi);
        }else{
          const existingActId = this.classGrid.get(act.classId)[s];
          if(existingActId >= 0){
            if(!conflictsSet.has(existingActId)){
              const existingAct = this.activities[existingActId];
              if(existingAct && this.getCanonMonKey(existingAct.mon) === actCanon){
                subjectPeriods.push(pi);
              }
            }
          }else if(this.fixedSlots.has(`${act.classId}|${s}`)){
            const fix = this.fixedSlots.get(`${act.classId}|${s}`);
            if(fix && fix.mon && this.getCanonMonKey(fix.mon) === actCanon){
              subjectPeriods.push(pi);
            }
          }
        }
      }

      // 1. Tuyệt đối không được vượt quá giới hạn trên
      if(subjectPeriods.length > maxPerSession){
        return { possible: false, conflicts: [] };
      }

      // 2. Bắt buộc các tiết cùng môn trong cùng 1 buổi phải xếp LIỀN NHAU (Contiguous)
      if(subjectPeriods.length >= 2){
        subjectPeriods.sort((a, b) => a - b);
        const span = subjectPeriods[subjectPeriods.length - 1] - subjectPeriods[0] + 1;
        if(span !== subjectPeriods.length){
          return { possible: false, conflicts: [] }; // Bị tách rời không liền nhau -> Chặn tuyệt đối!
        }
      }

      return {
        possible: true,
        conflicts: Array.from(conflictsSet)
      };
    }

    // Evaluates penalty for placing an activity at a slot to satisfy user constraints:
    // 1. Số tiết nghỉ liên tục tối đa là 1 (ConstraintTeachersMaxConsecutiveGaps = 1)
    // 2. Tối đa 1 buổi là 1 tiết nghỉ (ConstraintTeachersMaxGapsPerMorningAndAfternoon = 1)
    // 3. Tối thiểu 1 buổi dạy 2 tiết (ConstraintTeachersMinHoursDaily = 2 / No singletons)
    // (Bỏ ưu tiên ngày dạy)
    getPlacementPenalty(act, slot){
      if(!act.gv) return 0;
      const tList = parseTeacherList(act.gv);
      if(tList.length === 0) return 0;

      const d = Math.floor(slot / SLOTS_PER_DAY);
      const b = Math.floor((slot % SLOTS_PER_DAY) / PERIODS_PER_SESSION);
      const p = (slot % SLOTS_PER_DAY) % PERIODS_PER_SESSION;
      const sessionStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;

      let penalty = 0;

      for(const t of tList){
        const tGrid = this.teacherGrid.get(t);
        if(!tGrid) continue;

        const currentP = [];
        for(let pi = 0; pi < PERIODS_PER_SESSION; pi++){
          const s = sessionStart + pi;
          if(tGrid[s] >= 0 || tGrid[s] === -3){
            currentP.push(pi);
          }
        }

        if(currentP.length === 0){
          // Opening a new session for teacher t:
          // Discourage creating an isolated 1-period session (Tối thiểu 1 buổi 2 tiết)
          penalty += 350;
        }else{
          // Joining existing session (d, b) -> Helps reach >= 2 periods!
          // If the session currently has only 1 period, joining it turns it into >= 2 periods (SUPER BONUS)
          if(currentP.length === 1){
            const isFixedSingle = (tGrid[sessionStart + currentP[0]] === -3);
            penalty -= (isFixedSingle ? 700 : 250);
          }else if(currentP.length === 2){
            penalty -= 80;
          }else if(currentP.length === 3){
            penalty -= 30;
          }else if(currentP.length === 4){
            penalty -= 10;
          }

          const newP = currentP.concat([p]).sort((x, y) => x - y);
          const k = newP.length;
          const span = newP[k - 1] - newP[0] + 1;
          const totalGaps = span - k;

          let maxConsecGap = 0;
          for(let i = 0; i < k - 1; i++){
            const gap = newP[i + 1] - newP[i] - 1;
            if(gap > maxConsecGap) maxConsecGap = gap;
          }

          // Constraint 1: Số tiết nghỉ liên tục tối đa là 1 (Hard Penalty)
          if(maxConsecGap > 1){
            penalty += 2000 * maxConsecGap;
          }

          // Constraint 2: Tối đa 1 buổi là 1 tiết nghỉ (Hard Penalty)
          if(totalGaps > 1){
            penalty += 1500 * (totalGaps - 1);
          }

          // 1 tiết nghỉ hợp lệ
          if(totalGaps === 1 && maxConsecGap === 1){
            penalty += 10;
          }

          // Liền mạch 0 tiết nghỉ (Ưu tiên cao nhất)
          if(totalGaps === 0){
            penalty -= 100;
          }
        }
      }

      return penalty;
    }

    randomSwap(actId, level){
      if(level >= MAX_RECURSION_LEVEL) return false;
      if(this.nCalls >= this.limitCalls) return false;
      this.nCalls++;
      this.currentStep++;

      const act = this.activities[actId];
      if(!act || act.isFixed) return false;

      const candidateSlots = [];
      for(let s = 0; s < TOTAL_SLOTS; s++){
        candidateSlots.push(s);
      }
      this.rng.shuffle(candidateSlots);

      const evaluated = [];
      const zeroConflictSlots = [];

      for(const slot of candidateSlots){
        const res = this.getConflictsForSlot(act, slot);
        if(!res.possible) continue;

        const pen = this.getPlacementPenalty(act, slot);

        if(res.conflicts.length === 0){
          zeroConflictSlots.push({ slot, penalty: pen });
          continue;
        }

        const tabuKey = `${actId}|${slot}`;
        if(this.tabuMap.has(tabuKey) && this.tabuMap.get(tabuKey) > this.currentStep){
          continue;
        }

        evaluated.push({
          slot,
          conflicts: res.conflicts,
          conflictCount: res.conflicts.length,
          penalty: pen
        });
      }

      // If conflict-free slots exist, choose the best quality slot according to user rules
      if(zeroConflictSlots.length > 0){
        zeroConflictSlots.sort((a, b) => a.penalty - b.penalty);
        const bestSlot = zeroConflictSlots[0].slot;
        this.restoreStack.push({ actId, oldSlot: this.actPlacement[actId] });
        this.placeActivityDirect(actId, bestSlot);
        return true;
      }

      evaluated.sort((a, b) => {
        if(a.conflictCount !== b.conflictCount) return a.conflictCount - b.conflictCount;
        return a.penalty - b.penalty;
      });

      for(const cand of evaluated){
        const { slot, conflicts } = cand;

        let hasCycle = false;
        for(const confId of conflicts){
          if(this.swappedInBranch.has(confId)){
            hasCycle = true;
            break;
          }
        }
        if(hasCycle) continue;

        const restorePoint = this.restoreStack.length;
        this.restoreStack.push({ actId, oldSlot: this.actPlacement[actId] });

        for(const confId of conflicts){
          this.restoreStack.push({ actId: confId, oldSlot: this.actPlacement[confId] });
          this.unplaceActivity(confId);
          this.swappedInBranch.add(confId);
        }

        this.placeActivityDirect(actId, slot);

        const oldSlot = act.fixedSlot >= 0 ? act.fixedSlot : this.actPlacement[actId];
        if(oldSlot >= 0){
          this.tabuMap.set(`${actId}|${oldSlot}`, this.currentStep + this.activities.length);
        }

        let allDisplacedPlaced = true;
        for(const confId of conflicts){
          const ok = this.randomSwap(confId, level + 1);
          if(!ok){
            allDisplacedPlaced = false;
            break;
          }
        }

        if(allDisplacedPlaced){
          for(const confId of conflicts) this.swappedInBranch.delete(confId);
          return true;
        }

        while(this.restoreStack.length > restorePoint){
          const item = this.restoreStack.pop();
          this.unplaceActivity(item.actId);
          if(item.oldSlot >= 0){
            this.placeActivityDirect(item.actId, item.oldSlot);
          }
          this.swappedInBranch.delete(item.actId);
        }

        if(level >= 6) break;
      }

      return false;
    }

    // Deterministic 1-hop, 2-hop, Block-to-Singles, and Cross-Class Relocation
    tryEjectionChain(actId){
      const act = this.activities[actId];
      if(!act || this.actPlacement[actId] >= 0) return true;

      const candidateSlots = [];
      for(let s = 0; s < TOTAL_SLOTS; s++){
        candidateSlots.push(s);
      }
      this.rng.shuffle(candidateSlots);

      // 1. Direct placement check
      for(const slot of candidateSlots){
        const res = this.getConflictsForSlot(act, slot);
        if(res.possible && res.conflicts.length === 0){
          this.placeActivityDirect(actId, slot);
          return true;
        }
      }

      // 2. 1-hop relocation: Displace 1 activity B that can move to a free slot sB
      for(const slot of candidateSlots){
        const res = this.getConflictsForSlot(act, slot);
        if(!res.possible || res.conflicts.length !== 1) continue;

        const confId = res.conflicts[0];
        const confAct = this.activities[confId];
        if(!confAct || confAct.isFixed) continue;

        const oldConfSlot = this.actPlacement[confId];
        this.unplaceActivity(confId);
        this.placeActivityDirect(actId, slot);

        let placedConf = false;
        for(let sB = 0; sB < TOTAL_SLOTS; sB++){
          if(sB === oldConfSlot) continue;
          const resB = this.getConflictsForSlot(confAct, sB);
          if(resB.possible && resB.conflicts.length === 0){
            this.placeActivityDirect(confId, sB);
            placedConf = true;
            break;
          }
        }

        if(placedConf){
          return true;
        }

        this.unplaceActivity(actId);
        this.placeActivityDirect(confId, oldConfSlot);
      }

      // 3. 2-hop relocation: A -> slot (displaces B), B -> sB (displaces C), C -> sC (free)
      for(const slot of candidateSlots){
        const res = this.getConflictsForSlot(act, slot);
        if(!res.possible || res.conflicts.length !== 1) continue;

        const bId = res.conflicts[0];
        const bAct = this.activities[bId];
        if(!bAct || bAct.isFixed) continue;

        const oldBSlot = this.actPlacement[bId];
        this.unplaceActivity(bId);
        this.placeActivityDirect(actId, slot);

        let success2Hop = false;
        for(let sB = 0; sB < TOTAL_SLOTS; sB++){
          if(sB === oldBSlot) continue;
          const resB = this.getConflictsForSlot(bAct, sB);
          if(!resB.possible || resB.conflicts.length !== 1) continue;

          const cId = resB.conflicts[0];
          const cAct = this.activities[cId];
          if(!cAct || cAct.isFixed || cId === actId || cId === bId) continue;

          const oldCSlot = this.actPlacement[cId];
          this.unplaceActivity(cId);
          this.placeActivityDirect(bId, sB);

          for(let sC = 0; sC < TOTAL_SLOTS; sC++){
            if(sC === oldCSlot) continue;
            const resC = this.getConflictsForSlot(cAct, sC);
            if(resC.possible && resC.conflicts.length === 0){
              this.placeActivityDirect(cId, sC);
              success2Hop = true;
              break;
            }
          }

          if(success2Hop) break;

          this.unplaceActivity(bId);
          this.placeActivityDirect(cId, oldCSlot);
        }

        if(success2Hop){
          return true;
        }

        this.unplaceActivity(actId);
        this.placeActivityDirect(bId, oldBSlot);
      }

      // 4. Cross-Class Teacher Ejection: A -> slot in C1 (displaces B). B wants sFree in C1, but T_B is busy with D in C2 at sFree.
      // D moves to free slot sFree2 in C2 -> B takes sFree -> A takes slot!
      for(const slot of candidateSlots){
        const res = this.getConflictsForSlot(act, slot);
        if(!res.possible || res.conflicts.length !== 1) continue;

        const bId = res.conflicts[0];
        const bAct = this.activities[bId];
        if(!bAct || bAct.isFixed) continue;

        const oldBSlot = this.actPlacement[bId];
        this.unplaceActivity(bId);
        this.placeActivityDirect(actId, slot);

        let crossClassSuccess = false;
        for(let sFree = 0; sFree < TOTAL_SLOTS; sFree++){
          if(sFree === oldBSlot) continue;
          if(this.classGrid.get(bAct.classId)[sFree] !== -1) continue;

          const resB = this.getConflictsForSlot(bAct, sFree);
          if(!resB.possible || resB.conflicts.length !== 1) continue;

          const dId = resB.conflicts[0];
          const dAct = this.activities[dId];
          if(!dAct || dAct.isFixed || dAct.classId === bAct.classId) continue;

          const oldDSlot = this.actPlacement[dId];
          this.unplaceActivity(dId);
          this.placeActivityDirect(bId, sFree);

          for(let sFree2 = 0; sFree2 < TOTAL_SLOTS; sFree2++){
            if(sFree2 === oldDSlot) continue;
            const resD = this.getConflictsForSlot(dAct, sFree2);
            if(resD.possible && resD.conflicts.length === 0){
              this.placeActivityDirect(dId, sFree2);
              crossClassSuccess = true;
              break;
            }
          }

          if(crossClassSuccess) break;

          this.unplaceActivity(bId);
          this.placeActivityDirect(dId, oldDSlot);
        }

        if(crossClassSuccess){
          return true;
        }

        this.unplaceActivity(actId);
        this.placeActivityDirect(bId, oldBSlot);
      }

      return false;
    }

    solve(progressCallback = null){
      this.init();
      this.strictFetGaps = true;
      this.computeDifficultiesAndSort();

      let totalActivities = this.activities.length;
      this.limitCalls = Math.max(8000, 10 * totalActivities);

      for(let i = 0; i < this.activities.length; i++){
        const act = this.activities[i];
        if(this.actPlacement[act.id] >= 0) continue;

        this.nCalls = 0;
        this.randomSwap(act.id, 0);

        if(progressCallback && (i % 5 === 0 || i === this.activities.length - 1)){
          const placedNow = this.actPlacement.filter(s => s >= 0).reduce((sum, s, idx) => sum + (this.activities[idx]?.duration || 1), 0);
          const totalLessons = this.activities.reduce((sum, a) => sum + a.duration, 0);
          const pct = Math.min(85, Math.round((placedNow / Math.max(1, totalLessons)) * 85));
          progressCallback({
            percent: pct,
            placed: placedNow,
            total: totalLessons
          });
        }
      }

      // Keep 2-period blocks intact!

      // Multi-pass exhaustive placement for remaining activities
      for(let pass = 0; pass < 20; pass++){
        const unplacedActs = this.activities.filter(a => this.actPlacement[a.id] < 0);
        if(unplacedActs.length === 0) break;
        if(pass >= 6) this.strictFetGaps = false; // Relax in late fallback passes to guarantee 100% full placement

        this.limitCalls = Math.max(8000, 10 * this.activities.length);
        for(const uAct of unplacedActs){
          this.nCalls = 0;
          this.randomSwap(uAct.id, 0);
        }

        if(progressCallback){
          const placedNow = this.actPlacement.filter(s => s >= 0).reduce((sum, s, idx) => sum + (this.activities[idx]?.duration || 1), 0);
          const totalLessons = this.activities.reduce((sum, a) => sum + a.duration, 0);
          progressCallback({
            percent: 100,
            placed: placedNow,
            total: totalLessons
          });
        }
      }

      this.applyToDataTKB();

      let placed = 0;
      let unassigned = 0;
      this.activities.forEach((act, idx) => {
        if(this.actPlacement[idx] >= 0) placed += act.duration;
        else unassigned += act.duration;
      });
      placed += this.fixedSlots.size;

      return { ok: unassigned === 0, placed, unassigned, total: placed + unassigned };
    }

    applyToDataTKB(){
      const data = this.data;
      if(!data.tkb) data.tkb = {};
      if(!data.tkbLessonTeachers) data.tkbLessonTeachers = {};
      if(!data.tkbLessonRooms) data.tkbLessonRooms = {};

      this.classes.forEach(l => {
        const cid = String(l.id || "");
        if(!data.tkb[cid]) data.tkb[cid] = {};
        DAYS_LIST.forEach(thu => {
          if(!data.tkb[cid][thu]) data.tkb[cid][thu] = {};
          SESSIONS_LIST.forEach(buoi => {
            if(!Array.isArray(data.tkb[cid][thu][buoi])){
              data.tkb[cid][thu][buoi] = [null, null, null, null, null];
            }
          });
        });
      });

      this.classes.forEach(l => {
        const cid = String(l.id || "");
        DAYS_LIST.forEach(thu => {
          SESSIONS_LIST.forEach(buoi => {
            for(let ti = 0; ti < PERIODS_PER_SESSION; ti++){
              const slot = detailsToSlot(thu, buoi, ti);
              const key = `${cid}|${slot}`;
              if(this.fixedRawCells.has(key)){
                data.tkb[cid][thu][buoi][ti] = this.fixedRawCells.get(key);
              }else if(this.offSlots.has(key)){
                data.tkb[cid][thu][buoi][ti] = "OFF";
              }else{
                data.tkb[cid][thu][buoi][ti] = null;
              }
            }
          });
        });
      });

      this.activities.forEach(act => {
        const slot = this.actPlacement[act.id];
        if(slot < 0) return;

        for(let d = 0; d < act.duration; d++){
          const s = slot + d;
          const details = slotToDetails(s);
          const cid = act.classId;

          const key = `${cid}|${s}`;
          if(this.fixedRawCells.has(key) || this.offSlots.has(key)) continue;

          data.tkb[cid][details.thu][details.buoi][details.periodIdx] = act.mon;

          const tkbKey = `${cid}|${act.mon}`;
          if(act.gv) data.tkbLessonTeachers[tkbKey] = act.gv;
          if(act.room) data.tkbLessonRooms[tkbKey] = act.room;
        }
      });
    }

    getSnapshotTKB(){
      this.applyToDataTKB();
      return JSON.parse(JSON.stringify(this.data.tkb));
    }

    evaluateMetrics(){
      let soNgayMotTiet = 0;
      let soBuoiDay1 = 0;
      let soBuoiDay2 = 0;
      let soBuoiDay3 = 0;
      let tsBuoiDay = 0;
      let tsNgayDay = 0;
      let soBuoiTrong1 = 0;
      let soBuoiTrong2 = 0;

      this.teacherGrid.forEach((grid, tKey) => {
        if(!tKey) return;
        for(let d = 0; d < DAYS_LIST.length; d++){
          let dayTotal = 0;
          for(let b = 0; b < SESSIONS_LIST.length; b++){
            const sessionStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
            const taughtIndices = [];
            for(let p = 0; p < PERIODS_PER_SESSION; p++){
              const slot = sessionStart + p;
              const cell = grid[slot];
              if(cell >= 0 || cell === -3){ // taught or fixed
                taughtIndices.push(p);
              }
            }

            const k = taughtIndices.length;
            dayTotal += k;
            if(k > 0){
              tsBuoiDay++;
              if(k === 1) soBuoiDay1++;
              else if(k === 2) soBuoiDay2++;
              else if(k === 3) soBuoiDay3++;

              const first = taughtIndices[0];
              const last = taughtIndices[k - 1];
              const span = last - first + 1;
              const gaps = span - k;
              if(gaps === 1){
                soBuoiTrong1++;
              }else if(gaps >= 2){
                soBuoiTrong2++;
              }
            }
          }
          if(dayTotal > 0) tsNgayDay++;
          if(dayTotal === 1) soNgayMotTiet++;
        }
      });

      return { soNgayMotTiet, soBuoiDay1, soBuoiDay2, soBuoiDay3, tsBuoiDay, tsNgayDay, soBuoiTrong1, soBuoiTrong2 };
    }

    loadExistingSchedule(){
      this.init();
      const data = this.data;
      const actList = [];
      let actCounter = 0;

      // 1. Load currently placed movable cells with intelligent pair preservation
      this.classes.forEach(lop => {
        const cid = String(lop.id || "");
        const classCanon = lop.ten2 || lop.ten || cid;
        DAYS_LIST.forEach(thu => {
          SESSIONS_LIST.forEach(buoi => {
            const arr = data.tkb?.[cid]?.[thu]?.[buoi] || [];
            let ti = 0;
            while(ti < PERIODS_PER_SESSION){
              const slot = detailsToSlot(thu, buoi, ti);
              const cell = arr[ti];
              if(!cell || cell === "OFF" || this.isCellOff(cell) || this.isCellFixed(cell, cid, slot)){
                ti++;
                continue;
              }

              const mon = this.extractMon(cell);
              const sCanon = this.getCanonMonKey(mon);
              const gv = this.getTeacherForClassMon(lop, mon);
              const rm = this.getRoomForClassMon(lop, mon);

              // Check if next period in same session is identical subject with lessonBlocks[2].min > 0
              let blockLen = 1;
              if(ti + 1 < PERIODS_PER_SESSION){
                const nextCell = arr[ti + 1];
                const nextSlot = detailsToSlot(thu, buoi, ti + 1);
                if(nextCell && nextCell !== "OFF" && !this.isCellOff(nextCell) && !this.isCellFixed(nextCell, cid, nextSlot)){
                  const nextMon = this.extractMon(nextCell);
                  const nextCanon = this.getCanonMonKey(nextMon);
                  if(nextCanon === sCanon){
                    const req = this.classSubjectLessonBlocks ? (
                      this.classSubjectLessonBlocks.get(`${cid}|${sCanon}|2`) ||
                      this.classSubjectLessonBlocks.get(`${classCanon}|${sCanon}|2`)
                    ) : null;
                    if(req && req.min > 0){
                      blockLen = 2;
                    }
                  }
                }
              }

              const act = {
                id: actCounter++,
                classId: cid,
                classCanon,
                lop,
                mon,
                canonKey: sCanon,
                gv,
                room: rm,
                duration: blockLen,
                isFixed: false,
                fixedSlot: -1,
                initSlot: slot,
                nIncompatible: 0
              };
              actList.push(act);
              ti += blockLen;
            }
          });
        });
      });

      this.activities = actList;
      this.actPlacement = new Array(actList.length).fill(-1);

      // 2. Place initial existing activities into their slots
      this.activities.forEach(act => {
        if(act.initSlot >= 0){
          this.placeActivityDirect(act.id, act.initSlot);
        }
      });
    }

    // Recursive LNS Ruin-and-Recreate: Completely vacate a day for a teacher to give full Day Off
    tryVacateTeacherDay(tKey, targetDay, bestMetrics, initialMetrics){
      const tGrid = this.teacherGrid.get(tKey);
      if(!tGrid) return null;

      const targetActivities = [];
      for(let s = 0; s < SLOTS_PER_DAY; s++){
        const slot = targetDay * SLOTS_PER_DAY + s;
        const actId = tGrid[slot];
        if(actId === -3) return null; // Fixed cell on targetDay cannot be moved
        if(actId >= 0){
          targetActivities.push({ actId, slot });
        }
      }

      if(targetActivities.length === 0 || targetActivities.length > 2) return null;

      // Snapshot complete state
      const snapshotPlacement = this.actPlacement.slice();
      const snapshotClassGrid = new Map();
      this.classGrid.forEach((arr, cid) => snapshotClassGrid.set(cid, arr.slice()));
      const snapshotTeacherGrid = new Map();
      this.teacherGrid.forEach((arr, gv) => snapshotTeacherGrid.set(gv, arr.slice()));
      const snapshotRoomGrid = new Map();
      this.roomGrid.forEach((arr, rm) => snapshotRoomGrid.set(rm, arr.slice()));

      // 1. Unplace all target activities of this teacher on targetDay
      for(const item of targetActivities){
        this.unplaceActivity(item.actId);
      }

      // 2. Temporarily forbid targetDay for teacher tKey
      const tempForbiddenSlots = [];
      for(let s = 0; s < SLOTS_PER_DAY; s++){
        const slot = targetDay * SLOTS_PER_DAY + s;
        const key = `${tKey}|${slot}`;
        if(!this.teacherOffSlots.has(key)){
          this.teacherOffSlots.add(key);
          tempForbiddenSlots.push(key);
        }
      }

      // 3. Re-place all target activities using recursive randomSwap (LNS)
      let allPlaced = true;
      this.limitCalls = 250;

      for(const item of targetActivities){
        this.nCalls = 0;
        const ok = this.randomSwap(item.actId, 0);
        if(!ok){
          allPlaced = false;
          break;
        }
      }

      // 4. Remove temporary forbidden flags
      for(const key of tempForbiddenSlots){
        this.teacherOffSlots.delete(key);
      }

      // 5. If all placed successfully, check if quality improved (Maximum Day Reduction without increasing 1-period sessions or 2-period gaps)
      if(allPlaced){
        const currentM = this.evaluateMetrics();
        if(currentM.soBuoiDay1 <= bestMetrics.soBuoiDay1 && currentM.soBuoiTrong2 <= initialMetrics.soBuoiTrong2 && (currentM.tsNgayDay < bestMetrics.tsNgayDay || currentM.tsBuoiDay < bestMetrics.tsBuoiDay)){
          return currentM;
        }
      }

      // Backtrack to snapshot if not successful
      this.actPlacement = snapshotPlacement;
      this.classGrid = snapshotClassGrid;
      this.teacherGrid = snapshotTeacherGrid;
      this.roomGrid = snapshotRoomGrid;
      return null;
    }

    // Recursive LNS Ruin-and-Recreate: Completely vacate a half-day session (Sang/Chieu) for a teacher to reduce total sessions
    tryVacateTeacherSession(tKey, targetDay, targetBuoi, bestMetrics, initialMetrics, mode = "optimize_sessions"){
      const tGrid = this.teacherGrid.get(tKey);
      if(!tGrid) return null;

      const sessionStart = targetDay * SLOTS_PER_DAY + targetBuoi * PERIODS_PER_SESSION;
      const targetActivities = [];
      for(let p = 0; p < PERIODS_PER_SESSION; p++){
        const slot = sessionStart + p;
        const actId = tGrid[slot];
        if(actId === -3) return null; // Fixed cell cannot be moved
        if(actId >= 0){
          targetActivities.push({ actId, slot });
        }
      }

      if(targetActivities.length === 0 || targetActivities.length > 3) return null;

      // Snapshot complete state
      const snapshotPlacement = this.actPlacement.slice();
      const snapshotClassGrid = new Map();
      this.classGrid.forEach((arr, cid) => snapshotClassGrid.set(cid, arr.slice()));
      const snapshotTeacherGrid = new Map();
      this.teacherGrid.forEach((arr, gv) => snapshotTeacherGrid.set(gv, arr.slice()));
      const snapshotRoomGrid = new Map();
      this.roomGrid.forEach((arr, rm) => snapshotRoomGrid.set(rm, arr.slice()));

      // 1. Unplace all target activities of this teacher on (targetDay, targetBuoi)
      for(const item of targetActivities){
        this.unplaceActivity(item.actId);
      }

      // 2. Temporarily forbid (targetDay, targetBuoi) for teacher tKey
      const tempForbiddenSlots = [];
      for(let p = 0; p < PERIODS_PER_SESSION; p++){
        const slot = sessionStart + p;
        const key = `${tKey}|${slot}`;
        if(!this.teacherOffSlots.has(key)){
          this.teacherOffSlots.add(key);
          tempForbiddenSlots.push(key);
        }
      }

      // 3. Re-place all target activities using recursive randomSwap (LNS)
      let allPlaced = true;
      this.limitCalls = 250;

      for(const item of targetActivities){
        this.nCalls = 0;
        const ok = this.randomSwap(item.actId, 0);
        if(!ok){
          allPlaced = false;
          break;
        }
      }

      // 4. Remove temporary forbidden flags
      for(const key of tempForbiddenSlots){
        this.teacherOffSlots.delete(key);
      }

      // 5. If all placed successfully, check if metric improved for the active mode
      if(allPlaced && this.isLessonBlockSafe()){
        const currentM = this.evaluateMetrics();
        if(this.compareMetrics(currentM, bestMetrics, mode) < 0){
          return currentM;
        }
      }

      // Backtrack
      this.actPlacement = snapshotPlacement;
      this.classGrid = snapshotClassGrid;
      this.teacherGrid = snapshotTeacherGrid;
      this.roomGrid = snapshotRoomGrid;
      return null;
    }

    // Same-Teacher Same-Class Pair Merging: consolidates single-period activities of the same teacher in the same class
    // Intra-Class Same-Teacher Consolidation: Merges multiple single periods of the same teacher in the same class into the same session
    // Intra-Teacher Singleton Consolidation: Merges single periods of a teacher across sessions into active sessions
    tryConsolidateTeacherSingletons(bestMetrics, initialMetrics, maxGap2Limit = Infinity, onProgress = null){
      const DAYS = DAYS_LIST.length;
      const SESSIONS = SESSIONS_LIST.length;
      const PERIODS = PERIODS_PER_SESSION;
      let currentBest = { ...bestMetrics };
      let anyImproved = false;

      const teacherList = Array.from(this.teacherGrid.keys()).filter(Boolean);
      this.rng.shuffle(teacherList);

      for(const tKey of teacherList){
        const tGrid = this.teacherGrid.get(tKey);
        if(!tGrid) continue;

        // Find all single-period sessions of teacher tKey
        const singleSessions = [];
        const activeSessions = [];

        for(let d = 0; d < DAYS; d++){
          for(let b = 0; b < SESSIONS; b++){
            const sStart = d * 10 + b * 5;
            const taught = [];
            for(let p = 0; p < PERIODS; p++){
              const s = sStart + p;
              if(tGrid[s] >= 0){
                const act = this.activities[tGrid[s]];
                if(act && !act.isFixed && act.duration === 1){
                  taught.push({ slot: s, actId: tGrid[s], p });
                }
              }else if(tGrid[s] === -3){
                taught.push({ slot: s, actId: -3, p });
              }
            }
            if(taught.length === 1 && taught[0].actId >= 0){
              singleSessions.push({ day: d, buoi: b, sStart, item: taught[0] });
            }else if(taught.length >= 1){
              activeSessions.push({ day: d, buoi: b, sStart, cnt: taught.length });
            }
          }
        }

        if(singleSessions.length === 0 || activeSessions.length === 0) continue;
        activeSessions.sort((a, b) => b.cnt - a.cnt);

        for(const single of singleSessions){
          const act1 = this.activities[single.item.actId];
          if(!act1 || act1.isFixed || act1.duration !== 1) continue;

          const cGrid1 = this.classGrid.get(act1.classId);
          if(!cGrid1) continue;

          let consResolved = false;

          for(const targetSess of activeSessions){
            if(targetSess.day === single.day && targetSess.buoi === single.buoi) continue;

            for(let p2 = 0; p2 < PERIODS; p2++){
              const s2 = targetSess.sStart + p2;
              if(this.offSlots.has(`${act1.classId}|${s2}`)) continue;
              if(tGrid[s2] >= 0 || tGrid[s2] === -3) continue;

              const actId2 = cGrid1[s2];
              if(actId2 < 0) continue;

              const act2 = this.activities[actId2];
              if(!act2 || act2.isFixed || act2.duration !== 1) continue;

              const tDstGrid = this.teacherGrid.get(act2.gv);

              // 1. Try 2-way direct swap
              if(tDstGrid && tDstGrid[single.item.slot] < 0 && tDstGrid[single.item.slot] !== -3){
                this.unplaceActivity(act1.id);
                this.unplaceActivity(act2.id);

                const r1 = this.getConflictsForSlot(act1, s2);
                const r2 = this.getConflictsForSlot(act2, single.item.slot);

                if(r1.possible && r1.conflicts.length === 0 && r2.possible && r2.conflicts.length === 0){
                  this.placeActivityDirect(act1.id, s2);
                  this.placeActivityDirect(act2.id, single.item.slot);

                  if(this.isLessonBlockSafe(act1, act2)){
                    const m = this.evaluateMetrics();
                    if(m.soBuoiDay1 < currentBest.soBuoiDay1 && m.soBuoiTrong2 <= maxGap2Limit){
                      currentBest = { ...m };
                      anyImproved = true;
                      consResolved = true;
                      if(typeof onProgress === "function") onProgress(currentBest);
                      break;
                    }
                  }
                  this.unplaceActivity(act1.id);
                  this.unplaceActivity(act2.id);
                }
                this.placeActivityDirect(act1.id, single.item.slot);
                this.placeActivityDirect(act2.id, s2);
              }

              if(consResolved) break;

              // 2. Try 3-way cyclic swap
              for(let s3 = 0; s3 < 60; s3++){
                if(s3 === single.item.slot || s3 === s2 || this.offSlots.has(`${act1.classId}|${s3}`)) continue;
                const actId3 = cGrid1[s3];
                if(actId3 < 0) continue;
                const act3 = this.activities[actId3];
                if(!act3 || act3.isFixed || act3.duration !== 1) continue;

                this.unplaceActivity(act1.id);
                this.unplaceActivity(act2.id);
                this.unplaceActivity(act3.id);

                const r1 = this.getConflictsForSlot(act1, s2);
                const r2 = this.getConflictsForSlot(act2, s3);
                const r3 = this.getConflictsForSlot(act3, single.item.slot);

                if(r1.possible && r1.conflicts.length === 0 &&
                   r2.possible && r2.conflicts.length === 0 &&
                   r3.possible && r3.conflicts.length === 0){
                  this.placeActivityDirect(act1.id, s2);
                  this.placeActivityDirect(act2.id, s3);
                  this.placeActivityDirect(act3.id, single.item.slot);

                  if(this.isLessonBlockSafe(act1, act2, act3)){
                    const m = this.evaluateMetrics();
                    if(m.soBuoiDay1 < currentBest.soBuoiDay1 && m.soBuoiTrong2 <= maxGap2Limit){
                      currentBest = { ...m };
                      anyImproved = true;
                      consResolved = true;
                      if(typeof onProgress === "function") onProgress(currentBest);
                      break;
                    }
                  }
                  this.unplaceActivity(act1.id);
                  this.unplaceActivity(act2.id);
                  this.unplaceActivity(act3.id);
                }
                this.placeActivityDirect(act1.id, single.item.slot);
                this.placeActivityDirect(act2.id, s2);
                this.placeActivityDirect(act3.id, s3);
              }

              if(consResolved) break;
            }
            if(consResolved) break;
          }
        }
      }
      return anyImproved ? currentBest : null;
    }

    // Inbound Singleton Reinforcement: pulls lessons from multi-period sessions into 1-period sessions to reach >= 2 periods
    tryReinforceTeacherSingletons(bestMetrics, initialMetrics, maxGap2Limit = Infinity, onProgress = null){
      const DAYS = DAYS_LIST.length;
      const SESSIONS = SESSIONS_LIST.length;
      const PERIODS = PERIODS_PER_SESSION;
      let currentBest = { ...bestMetrics };
      let anyImproved = false;

      const teacherList = Array.from(this.teacherGrid.keys()).filter(Boolean);
      this.rng.shuffle(teacherList);

      for(const tKey of teacherList){
        const tGrid = this.teacherGrid.get(tKey);
        if(!tGrid) continue;

        for(let d = 0; d < DAYS; d++){
          for(let b = 0; b < SESSIONS; b++){
            const sStart = d * 10 + b * 5;
            let taughtCount = 0;
            let singleSlot = -1;
            for(let p = 0; p < PERIODS; p++){
              const s = sStart + p;
              if(tGrid[s] >= 0 || tGrid[s] === -3){
                taughtCount++;
                singleSlot = s;
              }
            }
            if(taughtCount !== 1) continue;

            const richSessions = [];
            for(let d2 = 0; d2 < DAYS; d2++){
              for(let b2 = 0; b2 < SESSIONS; b2++){
                if(d2 === d && b2 === b) continue;
                const sStart2 = d2 * 10 + b2 * 5;
                const movableActs = [];
                let totalPeriods = 0;
                for(let p2 = 0; p2 < PERIODS; p2++){
                  const s2 = sStart2 + p2;
                  if(tGrid[s2] >= 0){
                    totalPeriods++;
                    const a = this.activities[tGrid[s2]];
                    if(a && !a.isFixed && a.duration === 1){
                      movableActs.push({ act: a, slot: s2 });
                    }
                  }else if(tGrid[s2] === -3){
                    totalPeriods++;
                  }
                }
                if(totalPeriods >= 3 && movableActs.length > 0){
                  richSessions.push({ sStart: sStart2, movableActs, totalPeriods });
                }
              }
            }
            if(richSessions.length === 0) continue;
            richSessions.sort((x, y) => y.totalPeriods - x.totalPeriods);

            let reinResolved = false;
            for(const rich of richSessions){
              for(const item of rich.movableActs){
                const actToPull = item.act;
                const pullCGrid = this.classGrid.get(actToPull.classId);
                if(!pullCGrid) continue;

                for(let p = 0; p < PERIODS; p++){
                  const sTarget = sStart + p;
                  if(sTarget === singleSlot || this.offSlots.has(`${actToPull.classId}|${sTarget}`)) continue;
                  if(tGrid[sTarget] >= 0 || tGrid[sTarget] === -3) continue;

                  const existingActId = pullCGrid[sTarget];
                  if(existingActId < 0) continue;

                  const existingAct = this.activities[existingActId];
                  if(!existingAct || existingAct.isFixed || existingAct.duration !== 1) continue;

                  const existingTGrid = this.teacherGrid.get(existingAct.gv);
                  // 2-way swap
                  if(existingTGrid && existingTGrid[item.slot] < 0 && existingTGrid[item.slot] !== -3){
                    this.unplaceActivity(actToPull.id);
                    this.unplaceActivity(existingAct.id);

                    const r1 = this.getConflictsForSlot(actToPull, sTarget);
                    const r2 = this.getConflictsForSlot(existingAct, item.slot);

                    if(r1.possible && r1.conflicts.length === 0 && r2.possible && r2.conflicts.length === 0){
                      this.placeActivityDirect(actToPull.id, sTarget);
                      this.placeActivityDirect(existingAct.id, item.slot);

                      if(this.isLessonBlockSafe(actToPull, existingAct)){
                        const m = this.evaluateMetrics();
                        if(m.soBuoiDay1 < currentBest.soBuoiDay1 && m.soBuoiTrong2 <= maxGap2Limit){
                          currentBest = { ...m };
                          anyImproved = true;
                          reinResolved = true;
                          if(typeof onProgress === "function") onProgress(currentBest);
                          break;
                        }
                      }
                      this.unplaceActivity(actToPull.id);
                      this.unplaceActivity(existingAct.id);
                    }
                    this.placeActivityDirect(actToPull.id, item.slot);
                    this.placeActivityDirect(existingAct.id, sTarget);
                  }
                  if(reinResolved) break;

                  // 3-way cyclic swap
                  for(let s3 = 0; s3 < 60; s3++){
                    if(s3 === item.slot || s3 === sTarget || this.offSlots.has(`${actToPull.classId}|${s3}`)) continue;
                    const actId3 = pullCGrid[s3];
                    if(actId3 < 0) continue;
                    const act3 = this.activities[actId3];
                    if(!act3 || act3.isFixed || act3.duration !== 1) continue;

                    this.unplaceActivity(actToPull.id);
                    this.unplaceActivity(existingAct.id);
                    this.unplaceActivity(act3.id);

                    const r1 = this.getConflictsForSlot(actToPull, sTarget);
                    const r2 = this.getConflictsForSlot(existingAct, s3);
                    const r3 = this.getConflictsForSlot(act3, item.slot);

                    if(r1.possible && r1.conflicts.length === 0 &&
                       r2.possible && r2.conflicts.length === 0 &&
                       r3.possible && r3.conflicts.length === 0){
                      this.placeActivityDirect(actToPull.id, sTarget);
                      this.placeActivityDirect(existingAct.id, s3);
                      this.placeActivityDirect(act3.id, item.slot);

                      if(this.isLessonBlockSafe(actToPull, existingAct, act3)){
                        const m = this.evaluateMetrics();
                        if(m.soBuoiDay1 < currentBest.soBuoiDay1 && m.soBuoiTrong2 <= maxGap2Limit){
                          currentBest = { ...m };
                          anyImproved = true;
                          reinResolved = true;
                          if(typeof onProgress === "function") onProgress(currentBest);
                          break;
                        }
                      }
                      this.unplaceActivity(actToPull.id);
                      this.unplaceActivity(existingAct.id);
                      this.unplaceActivity(act3.id);
                    }
                    this.placeActivityDirect(actToPull.id, item.slot);
                    this.placeActivityDirect(existingAct.id, sTarget);
                    this.placeActivityDirect(act3.id, s3);
                  }
                  if(reinResolved) break;
                }
                if(reinResolved) break;
              }
              if(reinResolved) break;
            }
          }
        }
      }
      return anyImproved ? currentBest : null;
    }

    // Comprehensive Singleton Obliterator: thoroughly merges 1-period teaching sessions across the whole school using 2-way and 3-way cycles
    obliterateAllTeacherSingletons(maxPasses = 15, maxGap2Limit = Infinity, onProgress = null){
      const DAYS = DAYS_LIST.length;
      const SESSIONS = SESSIONS_LIST.length;
      const PERIODS = PERIODS_PER_SESSION;
      let currentBest = this.evaluateMetrics();
      let anyImproved = false;

      for(let pass = 0; pass < maxPasses; pass++){
        if(currentBest.soBuoiDay1 === 0) break;
        let passImproved = false;

        const teacherList = Array.from(this.teacherGrid.keys()).filter(Boolean);
        this.rng.shuffle(teacherList);

        for(const tKey of teacherList){
          const tGrid = this.teacherGrid.get(tKey);
          if(!tGrid) continue;

          for(let d = 0; d < DAYS; d++){
            for(let b = 0; b < SESSIONS; b++){
              const sStart = d * 10 + b * 5;
              const taught = [];
              for(let p = 0; p < PERIODS; p++){
                const s = sStart + p;
                if(tGrid[s] >= 0){
                  const act = this.activities[tGrid[s]];
                  if(act && !act.isFixed && act.duration === 1){
                    taught.push({ slot: s, actId: tGrid[s], p });
                  }
                }else if(tGrid[s] === -3){
                  taught.push({ slot: s, actId: -3, p });
                }
              }

              if(taught.length !== 1 || taught[0].actId < 0) continue;

              const s1 = taught[0].slot;
              const act1 = this.activities[taught[0].actId];
              const cGrid = this.classGrid.get(act1.classId);
              if(!cGrid) continue;

              const targetSessions = [];
              for(let d2 = 0; d2 < DAYS; d2++){
                for(let b2 = 0; b2 < SESSIONS; b2++){
                  if(d2 === d && b2 === b) continue;
                  const sStart2 = d2 * 10 + b2 * 5;
                  let cnt = 0;
                  for(let p2 = 0; p2 < PERIODS; p2++){
                    if(tGrid[sStart2 + p2] >= 0 || tGrid[sStart2 + p2] === -3) cnt++;
                  }
                  if(cnt >= 1 && cnt < 5){
                    targetSessions.push({ sStart: sStart2, cnt });
                  }
                }
              }
              targetSessions.sort((x, y) => y.cnt - x.cnt);

              let resolved = false;

              for(const target of targetSessions){
                for(let p2 = 0; p2 < PERIODS; p2++){
                  const s2 = target.sStart + p2;
                  if(this.offSlots.has(`${act1.classId}|${s2}`)) continue;
                  if(tGrid[s2] >= 0 || tGrid[s2] === -3) continue;

                  const actId2 = cGrid[s2];
                  if(actId2 < 0) continue;

                  const act2 = this.activities[actId2];
                  if(!act2 || act2.isFixed || act2.duration !== 1) continue;

                  const tDstGrid = this.teacherGrid.get(act2.gv);

                  // Case 1: 2-way direct swap
                  if(tDstGrid && tDstGrid[s1] < 0 && tDstGrid[s1] !== -3){
                    this.unplaceActivity(act1.id);
                    this.unplaceActivity(act2.id);

                    const r1 = this.getConflictsForSlot(act1, s2);
                    const r2 = this.getConflictsForSlot(act2, s1);

                    if(r1.possible && r1.conflicts.length === 0 && r2.possible && r2.conflicts.length === 0){
                      this.placeActivityDirect(act1.id, s2);
                      this.placeActivityDirect(act2.id, s1);

                      if(this.isLessonBlockSafe(act1, act2)){
                        const m = this.evaluateMetrics();
                        if((m.soBuoiDay1 < currentBest.soBuoiDay1 || (m.soBuoiDay1 === currentBest.soBuoiDay1 && m.tsBuoiDay < currentBest.tsBuoiDay)) && m.soBuoiTrong2 <= maxGap2Limit){
                          currentBest = { ...m };
                          anyImproved = true;
                          passImproved = true;
                          resolved = true;
                          if(typeof onProgress === "function") onProgress(currentBest);
                          break;
                        }
                      }
                      this.unplaceActivity(act1.id);
                      this.unplaceActivity(act2.id);
                    }
                    this.placeActivityDirect(act1.id, s1);
                    this.placeActivityDirect(act2.id, s2);
                  }

                  if(resolved) break;

                  // Case 2: 3-way cyclic swap
                  for(let s3 = 0; s3 < 60; s3++){
                    if(s3 === s1 || s3 === s2 || this.offSlots.has(`${act1.classId}|${s3}`)) continue;
                    const actId3 = cGrid[s3];
                    if(actId3 < 0) continue; // Must be a closed cycle so slot s1 is not left empty

                    const act3 = this.activities[actId3];
                    if(!act3 || act3.isFixed || act3.duration !== 1) continue;

                    this.unplaceActivity(act1.id);
                    this.unplaceActivity(act2.id);
                    this.unplaceActivity(act3.id);

                    const r1 = this.getConflictsForSlot(act1, s2);
                    const r2 = this.getConflictsForSlot(act2, s3);
                    const r3 = this.getConflictsForSlot(act3, s1);

                    if(r1.possible && r1.conflicts.length === 0 &&
                       r2.possible && r2.conflicts.length === 0 &&
                       r3.possible && r3.conflicts.length === 0){
                      this.placeActivityDirect(act1.id, s2);
                      this.placeActivityDirect(act2.id, s3);
                      this.placeActivityDirect(act3.id, s1);

                      if(this.isLessonBlockSafe(act1, act2, act3)){
                        const m = this.evaluateMetrics();
                        if((m.soBuoiDay1 < currentBest.soBuoiDay1 || (m.soBuoiDay1 === currentBest.soBuoiDay1 && m.tsBuoiDay < currentBest.tsBuoiDay)) && m.soBuoiTrong2 <= maxGap2Limit){
                          currentBest = { ...m };
                          anyImproved = true;
                          passImproved = true;
                          resolved = true;
                          if(typeof onProgress === "function") onProgress(currentBest);
                          break;
                        }
                      }
                      this.unplaceActivity(act1.id);
                      this.unplaceActivity(act2.id);
                      this.unplaceActivity(act3.id);
                    }
                    this.placeActivityDirect(act1.id, s1);
                    this.placeActivityDirect(act2.id, s2);
                    this.placeActivityDirect(act3.id, s3);
                  }

                  if(resolved) break;
                }
                if(resolved) break;
              }
            }
          }
        }
        if(!passImproved) break;
      }
      return anyImproved ? currentBest : null;
    }

    obliterateAllThinTeacherSessions(maxPasses = 8, targetSizes = [1, 2], maxGap2Limit = Infinity, onProgress = null){
      let currentBest = this.evaluateMetrics();
      let anyImproved = false;

      for(let pass = 0; pass < maxPasses; pass++){
        let passImproved = false;
        const thinSessions = [];
        this.teacherGrid.forEach((tGrid, tKey) => {
          if(!tKey) return;
          for(let d = 0; d < DAYS_LIST.length; d++){
            for(let b = 0; b < SESSIONS_LIST.length; b++){
              const sStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
              let cnt = 0;
              for(let p = 0; p < PERIODS_PER_SESSION; p++){
                if(tGrid[sStart + p] >= 0 || tGrid[sStart + p] === -3) cnt++;
              }
              if(targetSizes.includes(cnt)){
                thinSessions.push({ tKey, d, b, cnt });
              }
            }
          }
        });

        this.rng.shuffle(thinSessions);
        thinSessions.sort((x, y) => x.cnt - y.cnt);

        for(const s of thinSessions.slice(0, 30)){
          const res = this.tryVacateTeacherSession(s.tKey, s.d, s.b, currentBest, currentBest);
          if(res && this.compareMetrics(res, currentBest, "optimize_sessions") < 0){
            currentBest = { ...res };
            anyImproved = true;
            passImproved = true;
            if(typeof onProgress === "function") onProgress(currentBest);
            break;
          }
        }

        if(!passImproved) break;
      }
      return anyImproved ? currentBest : null;
    }

    // Dedicated 1-Period-per-Day Eliminator (Spec: ANTIGRAVITY_GIAM_1_TIET_NGAY_v2.md)
    // Targets teachers who teach exactly 1 period on an entire day (combining Morning + Afternoon).
    fixDaySingletons(bestMetrics, onProgress = null){
      const DAYS = DAYS_LIST.length;
      const SESSIONS = SESSIONS_LIST.length;
      const PERIODS = PERIODS_PER_SESSION;
      let currentBest = { ...bestMetrics };
      let anyImproved = false;

      const teacherList = Array.from(this.teacherGrid.keys()).filter(Boolean);
      this.rng.shuffle(teacherList);

      for(const tKey of teacherList){
        const tGrid = this.teacherGrid.get(tKey);
        if(!tGrid) continue;

        for(let d = 0; d < DAYS; d++){
          let taught = [];
          for(let b = 0; b < SESSIONS; b++){
            const sStart = d * 10 + b * 5;
            for(let p = 0; p < PERIODS; p++){
              const slot = sStart + p;
              const cell = tGrid[slot];
              if(cell >= 0){
                const act = this.activities[cell];
                if(act && !act.isFixed && act.duration === 1){
                  taught.push({ slot, actId: cell, d, b, p });
                }
              }else if(cell === -3){
                taught.push({ slot, actId: -3, d, b, p });
              }
            }
          }

          // Exactly 1 period on this entire day!
          if(taught.length !== 1 || taught[0].actId < 0) continue;

          const item1 = taught[0];
          const act1 = this.activities[item1.actId];
          if(!act1 || act1.isFixed) continue;
          const cGrid1 = this.classGrid.get(act1.classId);
          if(!cGrid1) continue;

          let dayResolved = false;

          // Strategy A: Move/Swap this single lesson to another day/session where teacher already teaches >= 1 period
          for(let d2 = 0; d2 < DAYS; d2++){
            if(d2 === d) continue;
            for(let b2 = 0; b2 < SESSIONS; b2++){
              const sStart2 = d2 * 10 + b2 * 5;
              let tCount = 0;
              for(let p = 0; p < PERIODS; p++){
                if(tGrid[sStart2 + p] >= 0 || tGrid[sStart2 + p] === -3) tCount++;
              }
              if(tCount === 0 || tCount >= PERIODS) continue;

              for(let p2 = 0; p2 < PERIODS; p2++){
                const s2 = sStart2 + p2;
                if(this.offSlots.has(`${act1.classId}|${s2}`)) continue;
                if(tGrid[s2] >= 0 || tGrid[s2] === -3) continue;

                const actId2 = cGrid1[s2];
                if(actId2 === -2 || actId2 === -3 || this.fixedSlots.has(`${act1.classId}|${s2}`)) continue;
                if(actId2 < 0){
                  this.unplaceActivity(act1.id);
                  const r1 = this.getConflictsForSlot(act1, s2);
                  if(r1.possible && r1.conflicts.length === 0){
                    this.placeActivityDirect(act1.id, s2);
                    if(this.isLessonBlockSafe(act1)){
                      const m = this.evaluateMetrics();
                      if(m.soNgayMotTiet < currentBest.soNgayMotTiet || (m.soNgayMotTiet === currentBest.soNgayMotTiet && m.soBuoiDay1 < currentBest.soBuoiDay1)){
                        currentBest = { ...m };
                        anyImproved = true;
                        dayResolved = true;
                        if(typeof onProgress === "function") onProgress(currentBest);
                        break;
                      }
                    }
                    this.unplaceActivity(act1.id);
                  }
                  this.placeActivityDirect(act1.id, item1.slot);
                  continue;
                }

                const act2 = this.activities[actId2];
                if(!act2 || act2.isFixed || act2.duration !== 1 || this.fixedSlots.has(`${act2.classId}|${item1.slot}`)) continue;
                const tDstGrid = this.teacherGrid.get(act2.gv);
                if(tDstGrid && tDstGrid[item1.slot] < 0 && tDstGrid[item1.slot] !== -3){
                  this.unplaceActivity(act1.id);
                  this.unplaceActivity(act2.id);

                  const r1 = this.getConflictsForSlot(act1, s2);
                  const r2 = this.getConflictsForSlot(act2, item1.slot);

                  if(r1.possible && r1.conflicts.length === 0 && r2.possible && r2.conflicts.length === 0){
                    this.placeActivityDirect(act1.id, s2);
                    this.placeActivityDirect(act2.id, item1.slot);

                    if(this.isLessonBlockSafe(act1, act2)){
                      const m = this.evaluateMetrics();
                      if(m.soNgayMotTiet < currentBest.soNgayMotTiet || (m.soNgayMotTiet === currentBest.soNgayMotTiet && m.soBuoiDay1 < currentBest.soBuoiDay1)){
                        currentBest = { ...m };
                        anyImproved = true;
                        dayResolved = true;
                        if(typeof onProgress === "function") onProgress(currentBest);
                        break;
                      }
                    }
                    this.unplaceActivity(act1.id);
                    this.unplaceActivity(act2.id);
                  }
                  this.placeActivityDirect(act1.id, item1.slot);
                  this.placeActivityDirect(act2.id, s2);
                }
              }
              if(dayResolved) break;
            }
            if(dayResolved) break;
          }

          if(dayResolved) continue;

          // Strategy B: 3-way cyclic swap to relocate the single lesson
          for(let s2 = 0; s2 < 60; s2++){
            if(s2 === item1.slot || this.offSlots.has(`${act1.classId}|${s2}`)) continue;
            const actId2 = cGrid1[s2];
            if(actId2 < 0 || this.fixedSlots.has(`${act1.classId}|${s2}`)) continue;
            const act2 = this.activities[actId2];
            if(!act2 || act2.isFixed || act2.duration !== 1) continue;

            const cGrid2 = this.classGrid.get(act2.classId);
            if(!cGrid2) continue;

            for(let s3 = 0; s3 < 60; s3++){
              if(s3 === s2 || s3 === item1.slot || this.offSlots.has(`${act2.classId}|${s3}`)) continue;
              const actId3 = cGrid2[s3];
              if(actId3 < 0 || this.fixedSlots.has(`${act2.classId}|${s3}`)) continue;
              const act3 = this.activities[actId3];
              if(!act3 || act3.isFixed || act3.duration !== 1 || this.fixedSlots.has(`${act3.classId}|${item1.slot}`)) continue;

              this.unplaceActivity(act1.id);
              this.unplaceActivity(act2.id);
              this.unplaceActivity(act3.id);

              const r1 = this.getConflictsForSlot(act1, s2);
              const r2 = this.getConflictsForSlot(act2, s3);
              const r3 = this.getConflictsForSlot(act3, item1.slot);

              if(r1.possible && r1.conflicts.length === 0 &&
                 r2.possible && r2.conflicts.length === 0 &&
                 r3.possible && r3.conflicts.length === 0){
                this.placeActivityDirect(act1.id, s2);
                this.placeActivityDirect(act2.id, s3);
                this.placeActivityDirect(act3.id, item1.slot);

                if(this.isLessonBlockSafe(act1, act2, act3)){
                  const m = this.evaluateMetrics();
                  if(m.soNgayMotTiet < currentBest.soNgayMotTiet || (m.soNgayMotTiet === currentBest.soNgayMotTiet && m.soBuoiDay1 < currentBest.soBuoiDay1)){
                    currentBest = { ...m };
                    anyImproved = true;
                    dayResolved = true;
                    if(typeof onProgress === "function") onProgress(currentBest);
                    break;
                  }
                }
                this.unplaceActivity(act1.id);
                this.unplaceActivity(act2.id);
                this.unplaceActivity(act3.id);
              }
              this.placeActivityDirect(act1.id, item1.slot);
              this.placeActivityDirect(act2.id, s2);
              this.placeActivityDirect(act3.id, s3);
            }
            if(dayResolved) break;
          }
        }
      }
      return anyImproved ? currentBest : null;
    }

    // Session Vacater for optimize_sessions: compacts teaching days/sessions to reduce total sessions and eliminate 2-3 period sessions
    tryVacateTeacherSessions(bestMetrics, initialMetrics, maxGap2Limit = Infinity, onProgress = null){
      const DAYS = DAYS_LIST.length;
      const SESSIONS = SESSIONS_LIST.length;
      const PERIODS = PERIODS_PER_SESSION;
      let currentBest = { ...bestMetrics };
      let anyImproved = false;

      const teacherList = Array.from(this.teacherGrid.keys()).filter(Boolean);
      this.rng.shuffle(teacherList);

      for(const tKey of teacherList){
        const tGrid = this.teacherGrid.get(tKey);
        if(!tGrid) continue;

        for(let d = 0; d < DAYS; d++){
          for(let b = 0; b < SESSIONS; b++){
            const sStart = d * 10 + b * 5;
            const taught = [];
            for(let p = 0; p < PERIODS; p++){
              const s = sStart + p;
              if(tGrid[s] >= 0){
                const act = this.activities[tGrid[s]];
                if(act && !act.isFixed && act.duration === 1){
                  taught.push({ slot: s, actId: tGrid[s], p });
                }
              }else if(tGrid[s] === -3){
                taught.push({ slot: s, actId: -3, p });
              }
            }

            // Target sessions with 1, 2, or 3 periods to vacate or consolidate into 4-5 periods
            if(taught.length === 0 || taught.length > 3 || taught.some(t => t.actId < 0)) continue;

            const targetSessions = [];
            for(let d2 = 0; d2 < DAYS; d2++){
              for(let b2 = 0; b2 < SESSIONS; b2++){
                if(d2 === d && b2 === b) continue;
                const sStart2 = d2 * 10 + b2 * 5;
                let cnt = 0;
                for(let p2 = 0; p2 < PERIODS; p2++){
                  if(tGrid[sStart2 + p2] >= 0 || tGrid[sStart2 + p2] === -3) cnt++;
                }
                if(cnt >= 1 && cnt + taught.length <= 5){
                  targetSessions.push({ sStart: sStart2, cnt });
                }
              }
            }
            if(targetSessions.length === 0) continue;
            targetSessions.sort((x, y) => y.cnt - x.cnt);

            for(const target of targetSessions){
              if(taught.length === 1){
                const s1 = taught[0].slot;
                const act1 = this.activities[taught[0].actId];
                const cGrid = this.classGrid.get(act1.classId);
                if(!cGrid) continue;

                let resolved = false;
                for(let p2 = 0; p2 < PERIODS; p2++){
                  const s2 = target.sStart + p2;
                  if(this.offSlots.has(`${act1.classId}|${s2}`)) continue;
                  if(tGrid[s2] >= 0 || tGrid[s2] === -3) continue;

                  const actId2 = cGrid[s2];
                  if(actId2 < 0) continue;
                  const act2 = this.activities[actId2];
                  if(!act2 || act2.isFixed || act2.duration !== 1) continue;

                  const tDstGrid = this.teacherGrid.get(act2.gv);
                  if(tDstGrid && tDstGrid[s1] < 0 && tDstGrid[s1] !== -3){
                    this.unplaceActivity(act1.id);
                    this.unplaceActivity(act2.id);

                    const r1 = this.getConflictsForSlot(act1, s2);
                    const r2 = this.getConflictsForSlot(act2, s1);

                    if(r1.possible && r1.conflicts.length === 0 && r2.possible && r2.conflicts.length === 0){
                      this.placeActivityDirect(act1.id, s2);
                      this.placeActivityDirect(act2.id, s1);

                      if(this.isLessonBlockSafe(act1, act2)){
                        const m = this.evaluateMetrics();
                        if(m.soBuoiDay1 <= bestMetrics.soBuoiDay1 && m.soNgayMotTiet <= bestMetrics.soNgayMotTiet){
                          if(m.tsBuoiDay < currentBest.tsBuoiDay || (m.tsBuoiDay === currentBest.tsBuoiDay && ((m.soBuoiDay2||0)*2 + (m.soBuoiDay3||0) < (currentBest.soBuoiDay2||0)*2 + (currentBest.soBuoiDay3||0) || m.tsNgayDay < currentBest.tsNgayDay))){
                            currentBest = { ...m };
                            anyImproved = true;
                            resolved = true;
                            if(typeof onProgress === "function") onProgress(currentBest);
                            break;
                          }
                        }
                      }
                      this.unplaceActivity(act1.id);
                      this.unplaceActivity(act2.id);
                    }
                    this.placeActivityDirect(act1.id, s1);
                    this.placeActivityDirect(act2.id, s2);
                  }
                  if(resolved) break;
                }
              }else if(taught.length === 2){
                const act1 = this.activities[taught[0].actId];
                const act2 = this.activities[taught[1].actId];
                if(!act1 || act1.isFixed || !act2 || act2.isFixed) continue;
                const cGrid1 = this.classGrid.get(act1.classId);
                const cGrid2 = this.classGrid.get(act2.classId);
                if(!cGrid1 || !cGrid2) continue;

                let resolved = false;
                for(let pA = 0; pA < PERIODS; pA++){
                  const sA = target.sStart + pA;
                  if(this.offSlots.has(`${act1.classId}|${sA}`) || tGrid[sA] >= 0 || tGrid[sA] === -3) continue;
                  const actIdA = cGrid1[sA];
                  if(actIdA < 0) continue;
                  const actA = this.activities[actIdA];
                  if(!actA || actA.isFixed || actA.duration !== 1) continue;
                  const tDstGridA = this.teacherGrid.get(actA.gv);
                  if(!tDstGridA || tDstGridA[taught[0].slot] >= 0 || tDstGridA[taught[0].slot] === -3) continue;

                  for(let pB = 0; pB < PERIODS; pB++){
                    if(pB === pA) continue;
                    const sB = target.sStart + pB;
                    if(this.offSlots.has(`${act2.classId}|${sB}`) || tGrid[sB] >= 0 || tGrid[sB] === -3) continue;
                    const actIdB = cGrid2[sB];
                    if(actIdB < 0) continue;
                    const actB = this.activities[actIdB];
                    if(!actB || actB.isFixed || actB.duration !== 1) continue;
                    const tDstGridB = this.teacherGrid.get(actB.gv);
                    if(!tDstGridB || tDstGridB[taught[1].slot] >= 0 || tDstGridB[taught[1].slot] === -3) continue;

                    this.unplaceActivity(act1.id);
                    this.unplaceActivity(act2.id);
                    this.unplaceActivity(actA.id);
                    this.unplaceActivity(actB.id);

                    const r1 = this.getConflictsForSlot(act1, sA);
                    const r2 = this.getConflictsForSlot(act2, sB);
                    const rA = this.getConflictsForSlot(actA, taught[0].slot);
                    const rB = this.getConflictsForSlot(actB, taught[1].slot);

                    if(r1.possible && r1.conflicts.length === 0 &&
                       r2.possible && r2.conflicts.length === 0 &&
                       rA.possible && rA.conflicts.length === 0 &&
                       rB.possible && rB.conflicts.length === 0){
                      this.placeActivityDirect(act1.id, sA);
                      this.placeActivityDirect(act2.id, sB);
                      this.placeActivityDirect(actA.id, taught[0].slot);
                      this.placeActivityDirect(actB.id, taught[1].slot);

                      if(this.isLessonBlockSafe(act1, act2, actA, actB)){
                        const m = this.evaluateMetrics();
                        if(m.soBuoiDay1 <= bestMetrics.soBuoiDay1 && m.soNgayMotTiet <= bestMetrics.soNgayMotTiet){
                          if(m.tsBuoiDay < currentBest.tsBuoiDay || (m.tsBuoiDay === currentBest.tsBuoiDay && ((m.soBuoiDay2||0)*2 + (m.soBuoiDay3||0) < (currentBest.soBuoiDay2||0)*2 + (currentBest.soBuoiDay3||0) || m.tsNgayDay < currentBest.tsNgayDay))){
                            currentBest = { ...m };
                            anyImproved = true;
                            resolved = true;
                            if(typeof onProgress === "function") onProgress(currentBest);
                            break;
                          }
                        }
                      }
                      this.unplaceActivity(act1.id);
                      this.unplaceActivity(act2.id);
                      this.unplaceActivity(actA.id);
                      this.unplaceActivity(actB.id);
                    }
                    this.placeActivityDirect(act1.id, taught[0].slot);
                    this.placeActivityDirect(act2.id, taught[1].slot);
                    this.placeActivityDirect(actA.id, sA);
                    this.placeActivityDirect(actB.id, sB);
                  }
                  if(resolved) break;
                }
              }
            }
          }
        }
      }
      return anyImproved ? currentBest : null;
    }

    // Targeted LNS Gap Crusher: specifically eliminates 2-period gaps (trống 2 tiết) and 1-period gaps
    tryCrushTeacherGaps(bestMetrics, initialMetrics, mode = "optimize_gap2", onProgress = null){
      const DAYS = DAYS_LIST.length;
      const SESSIONS = SESSIONS_LIST.length;
      const PERIODS = PERIODS_PER_SESSION;
      let currentBest = { ...bestMetrics };
      let anyImproved = false;

      const teacherList = Array.from(this.teacherGrid.keys()).filter(Boolean);
      this.rng.shuffle(teacherList);

      for(const tKey of teacherList){
        const tGrid = this.teacherGrid.get(tKey);
        if(!tGrid) continue;

        for(let d = 0; d < DAYS; d++){
          for(let b = 0; b < SESSIONS; b++){
            const sessionStart = d * 10 + b * 5;
            const taught = [];
            for(let p = 0; p < PERIODS; p++){
              const s = sessionStart + p;
              if(tGrid[s] >= 0 || tGrid[s] === -3){
                taught.push({ slot: s, actId: tGrid[s], p });
              }
            }

            const k = taught.length;
            if(k < 2) continue;

            let hasTargetGap = false;
            for(let i = 0; i < k - 1; i++){
              const g = taught[i + 1].p - taught[i].p - 1;
              if(mode === "optimize_gap2" && g >= 2){
                hasTargetGap = true;
                break;
              }else if(mode === "optimize_gap1" && g === 1){
                hasTargetGap = true;
                break;
              }
            }

            if(!hasTargetGap) continue;

            const movableTaught = taught.filter(t => t.actId >= 0 && !this.activities[t.actId].isFixed && this.activities[t.actId].duration === 1);
            if(movableTaught.length === 0) continue;

            let gapResolved = false;

            for(const srcItem of movableTaught){
              const act1 = this.activities[srcItem.actId];
              const cClassGrid = this.classGrid.get(act1.classId);
              if(!cClassGrid) continue;

              // 1. Try moving act1 into the internal gap or contiguous position
              for(let p = 0; p < PERIODS; p++){
                const targetSlot = sessionStart + p;
                if(tGrid[targetSlot] >= 0 || tGrid[targetSlot] === -3) continue;
                if(this.offSlots.has(`${act1.classId}|${targetSlot}`) || this.fixedSlots.has(`${act1.classId}|${targetSlot}`)) continue;

                const actId2 = cClassGrid[targetSlot];
                if(actId2 < 0) continue;

                const act2 = this.activities[actId2];
                if(!act2 || act2.isFixed || act2.duration !== 1 || this.fixedSlots.has(`${act2.classId}|${srcItem.slot}`)) continue;

                const tDstGrid = this.teacherGrid.get(act2.gv);

                // 2-way swap
                if(tDstGrid && tDstGrid[srcItem.slot] < 0 && tDstGrid[srcItem.slot] !== -3){
                  this.unplaceActivity(act1.id);
                  this.unplaceActivity(act2.id);

                  const r1 = this.getConflictsForSlot(act1, targetSlot);
                  const r2 = this.getConflictsForSlot(act2, srcItem.slot);

                  if(r1.possible && r1.conflicts.length === 0 && r2.possible && r2.conflicts.length === 0){
                    this.placeActivityDirect(act1.id, targetSlot);
                    this.placeActivityDirect(act2.id, srcItem.slot);

                    if(this.isLessonBlockSafe(act1, act2) && this.isLessonBlockSafe()){
                      const currentM = this.evaluateMetrics();
                      if(this.compareMetrics(currentM, currentBest, mode) < 0){
                        currentBest = { ...currentM };
                        anyImproved = true;
                        gapResolved = true;
                        if(typeof onProgress === "function") onProgress(currentBest);
                        break;
                      }
                    }
                    this.unplaceActivity(act1.id);
                    this.unplaceActivity(act2.id);
                  }
                  this.placeActivityDirect(act1.id, srcItem.slot);
                  this.placeActivityDirect(act2.id, targetSlot);
                }
                if(gapResolved) break;

                // 3-way cyclic swap
                for(let s3 = 0; s3 < 60; s3++){
                  if(s3 === srcItem.slot || s3 === targetSlot || this.offSlots.has(`${act1.classId}|${s3}`) || this.fixedSlots.has(`${act1.classId}|${s3}`)) continue;
                  const actId3 = cClassGrid[s3];
                  if(actId3 < 0) continue;
                  const act3 = this.activities[actId3];
                  if(!act3 || act3.isFixed || act3.duration !== 1 || this.fixedSlots.has(`${act3.classId}|${srcItem.slot}`) || this.fixedSlots.has(`${act2.classId}|${s3}`)) continue;

                  this.unplaceActivity(act1.id);
                  this.unplaceActivity(act2.id);
                  this.unplaceActivity(act3.id);

                  const r1 = this.getConflictsForSlot(act1, targetSlot);
                  const r2 = this.getConflictsForSlot(act2, s3);
                  const r3 = this.getConflictsForSlot(act3, srcItem.slot);

                  if(r1.possible && r1.conflicts.length === 0 &&
                     r2.possible && r2.conflicts.length === 0 &&
                     r3.possible && r3.conflicts.length === 0){
                    this.placeActivityDirect(act1.id, targetSlot);
                    this.placeActivityDirect(act2.id, s3);
                    this.placeActivityDirect(act3.id, srcItem.slot);

                    if(this.isLessonBlockSafe(act1, act2, act3) && this.isLessonBlockSafe()){
                      const currentM = this.evaluateMetrics();
                      if(this.compareMetrics(currentM, currentBest, mode) < 0){
                        currentBest = { ...currentM };
                        anyImproved = true;
                        gapResolved = true;
                        if(typeof onProgress === "function") onProgress(currentBest);
                        break;
                      }
                    }
                    this.unplaceActivity(act1.id);
                    this.unplaceActivity(act2.id);
                    this.unplaceActivity(act3.id);
                  }
                  this.placeActivityDirect(act1.id, srcItem.slot);
                  this.placeActivityDirect(act2.id, targetSlot);
                  this.placeActivityDirect(act3.id, s3);
                  if(gapResolved) break;
                }
                if(gapResolved) break;
              }
              if(gapResolved) break;
            }

            // 4. Cross-Session Consolidation: Relocate outlying lessons to other active sessions where teacher already teaches
            if(!gapResolved){
              for(const srcItem of movableTaught){
                const act1 = this.activities[srcItem.actId];
                if(!act1 || act1.isFixed) continue;

                const cClassGrid = this.classGrid.get(act1.classId);
                if(!cClassGrid) continue;

                for(let d2 = 0; d2 < DAYS; d2++){
                  for(let b2 = 0; b2 < SESSIONS; b2++){
                    if(d2 === d && b2 === b) continue;
                    const sStart2 = d2 * 10 + b2 * 5;

                    let tCount2 = 0;
                    for(let p2 = 0; p2 < PERIODS; p2++){
                      if(tGrid[sStart2 + p2] >= 0 || tGrid[sStart2 + p2] === -3) tCount2++;
                    }
                    if(tCount2 >= PERIODS) continue;

                    for(let p2 = 0; p2 < PERIODS; p2++){
                      const s2 = sStart2 + p2;
                      if(this.offSlots.has(`${act1.classId}|${s2}`) || this.fixedSlots.has(`${act1.classId}|${s2}`)) continue;
                      if(tGrid[s2] >= 0 || tGrid[s2] === -3) continue;

                      const actId2 = cClassGrid[s2];
                      if(actId2 < 0) continue;

                      const act2 = this.activities[actId2];
                      if(!act2 || act2.isFixed || act2.duration !== 1 || this.fixedSlots.has(`${act2.classId}|${srcItem.slot}`)) continue;

                      const tDstGrid = this.teacherGrid.get(act2.gv);
                      if(tDstGrid && tDstGrid[srcItem.slot] < 0 && tDstGrid[srcItem.slot] !== -3){
                        this.unplaceActivity(act1.id);
                        this.unplaceActivity(act2.id);

                        const r1 = this.getConflictsForSlot(act1, s2);
                        const r2 = this.getConflictsForSlot(act2, srcItem.slot);

                        if(r1.possible && r1.conflicts.length === 0 && r2.possible && r2.conflicts.length === 0){
                          this.placeActivityDirect(act1.id, s2);
                          this.placeActivityDirect(act2.id, srcItem.slot);

                          if(this.isLessonBlockSafe(act1, act2)){
                            const currentM = this.evaluateMetrics();
                            if(this.compareMetrics(currentM, currentBest, mode) < 0){
                              currentBest = { ...currentM };
                              anyImproved = true;
                              gapResolved = true;
                              if(typeof onProgress === "function") onProgress(currentBest);
                              break;
                            }
                          }
                          this.unplaceActivity(act1.id);
                          this.unplaceActivity(act2.id);
                        }
                        this.placeActivityDirect(act1.id, srcItem.slot);
                        this.placeActivityDirect(act2.id, s2);
                      }
                      if(gapResolved) break;
                    }
                    if(gapResolved) break;
                  }
                  if(gapResolved) break;
                }
                if(gapResolved) break;
              }
            }
          }
        }
      }
      return anyImproved ? currentBest : null;
    }

    // Inbound Gap-Filler (Spec: ANTIGRAVITY_KHU_2_TIET_TRONG.md De Xuat 3)
    // Searches from the perspective of the GAP, pulling matching lessons of teacher tKey from other sessions
    tryFillTeacherGapFromElsewhere(bestMetrics, initialMetrics, onProgress = null){
      const DAYS = DAYS_LIST.length;
      const SESSIONS = SESSIONS_LIST.length;
      const PERIODS = PERIODS_PER_SESSION;
      let currentBest = { ...bestMetrics };
      let anyImproved = false;

      const teacherList = Array.from(this.teacherGrid.keys()).filter(Boolean);
      this.rng.shuffle(teacherList);

      for(const tKey of teacherList){
        const tGrid = this.teacherGrid.get(tKey);
        if(!tGrid) continue;

        for(let d = 0; d < DAYS; d++){
          for(let b = 0; b < SESSIONS; b++){
            const sessionStart = d * 10 + b * 5;
            const taught = [];
            for(let p = 0; p < PERIODS; p++){
              const s = sessionStart + p;
              if(tGrid[s] >= 0 || tGrid[s] === -3){
                taught.push({ slot: s, actId: tGrid[s], p });
              }
            }

            const k = taught.length;
            if(k < 2 || k >= 5) continue;

            const taughtPSet = new Set(taught.map(t => t.p));
            const gapSlots = [];
            for(let p = taught[0].p + 1; p < taught[k - 1].p; p++){
              if(!taughtPSet.has(p)){
                gapSlots.push({ p, slot: sessionStart + p });
              }
            }

            if(gapSlots.length < 2) continue; // Only process sessions with gap >= 2

            // Look for lessons of the SAME teacher in other sessions to pull into this gap
            const donorLessons = [];
            for(let d2 = 0; d2 < DAYS; d2++){
              for(let b2 = 0; b2 < SESSIONS; b2++){
                if(d2 === d && b2 === b) continue;
                const sStart2 = d2 * 10 + b2 * 5;
                for(let p2 = 0; p2 < PERIODS; p2++){
                  const s2 = sStart2 + p2;
                  const actId2 = tGrid[s2];
                  if(actId2 >= 0){
                    const actDonor = this.activities[actId2];
                    if(actDonor && !actDonor.isFixed && actDonor.duration === 1){
                      donorLessons.push({ act: actDonor, srcSlot: s2, d: d2, b: b2 });
                    }
                  }
                }
              }
            }

            if(donorLessons.length === 0) continue;
            this.rng.shuffle(donorLessons);

            let gapFilled = false;
            for(const gapItem of gapSlots){
              const targetSlot = gapItem.slot;
              for(const donor of donorLessons){
                const actDonor = donor.act;
                const donorCGrid = this.classGrid.get(actDonor.classId);
                if(!donorCGrid) continue;

                if(this.offSlots.has(`${actDonor.classId}|${targetSlot}`) || this.fixedSlots.has(`${actDonor.classId}|${targetSlot}`)) continue;

                const occupantActId = donorCGrid[targetSlot];
                if(occupantActId === -2 || occupantActId === -3) continue;

                if(occupantActId < 0){
                  // Direct empty slot in donor class
                  this.unplaceActivity(actDonor.id);
                  const r1 = this.getConflictsForSlot(actDonor, targetSlot);
                  if(r1.possible && r1.conflicts.length === 0){
                    this.placeActivityDirect(actDonor.id, targetSlot);
                    if(this.isLessonBlockSafe(actDonor) && this.isLessonBlockSafe()){
                      const m = this.evaluateMetrics();
                      if(this.compareMetrics(m, currentBest, "optimize_gap2") < 0){
                        currentBest = { ...m };
                        anyImproved = true;
                        gapFilled = true;
                        if(typeof onProgress === "function") onProgress(currentBest);
                        break;
                      }
                    }
                    this.unplaceActivity(actDonor.id);
                  }
                  this.placeActivityDirect(actDonor.id, donor.srcSlot);
                  continue;
                }

                // 2-Way Swap with occupant
                const actOccupant = this.activities[occupantActId];
                if(!actOccupant || actOccupant.isFixed || actOccupant.duration !== 1) continue;
                if(this.fixedSlots.has(`${actOccupant.classId}|${donor.srcSlot}`)) continue;

                const occTGrid = this.teacherGrid.get(actOccupant.gv);
                if(occTGrid && occTGrid[donor.srcSlot] < 0 && occTGrid[donor.srcSlot] !== -3){
                  this.unplaceActivity(actDonor.id);
                  this.unplaceActivity(actOccupant.id);

                  const r1 = this.getConflictsForSlot(actDonor, targetSlot);
                  const r2 = this.getConflictsForSlot(actOccupant, donor.srcSlot);

                  if(r1.possible && r1.conflicts.length === 0 && r2.possible && r2.conflicts.length === 0){
                    this.placeActivityDirect(actDonor.id, targetSlot);
                    this.placeActivityDirect(actOccupant.id, donor.srcSlot);

                    if(this.isLessonBlockSafe(actDonor, actOccupant) && this.isLessonBlockSafe()){
                      const m = this.evaluateMetrics();
                      if(this.compareMetrics(m, currentBest, "optimize_gap2") < 0){
                        currentBest = { ...m };
                        anyImproved = true;
                        gapFilled = true;
                        if(typeof onProgress === "function") onProgress(currentBest);
                        break;
                      }
                    }
                    this.unplaceActivity(actDonor.id);
                    this.unplaceActivity(actOccupant.id);
                  }
                  this.placeActivityDirect(actDonor.id, donor.srcSlot);
                  this.placeActivityDirect(actOccupant.id, targetSlot);
                }
                if(gapFilled) break;
              }
              if(gapFilled) break;
            }
          }
        }
      }
      return anyImproved ? currentBest : null;
    }

    // Double Block Gap-Filler (Spec: ANTIGRAVITY_KHU_2_TIET_TRONG.md De Xuat 4)
    // Swaps a 2-period paired lesson (duration === 2) into an exact 2-period gap
    tryMoveDoubleBlockIntoGap(bestMetrics, initialMetrics, onProgress = null){
      const DAYS = DAYS_LIST.length;
      const SESSIONS = SESSIONS_LIST.length;
      const PERIODS = PERIODS_PER_SESSION;
      let currentBest = { ...bestMetrics };
      let anyImproved = false;

      const teacherList = Array.from(this.teacherGrid.keys()).filter(Boolean);
      this.rng.shuffle(teacherList);

      for(const tKey of teacherList){
        const tGrid = this.teacherGrid.get(tKey);
        if(!tGrid) continue;

        for(let d = 0; d < DAYS; d++){
          for(let b = 0; b < SESSIONS; b++){
            const sessionStart = d * 10 + b * 5;
            const taught = [];
            for(let p = 0; p < PERIODS; p++){
              const s = sessionStart + p;
              if(tGrid[s] >= 0 || tGrid[s] === -3){
                taught.push({ slot: s, actId: tGrid[s], p });
              }
            }

            const k = taught.length;
            if(k < 2) continue;

            for(let i = 0; i < k - 1; i++){
              const g = taught[i + 1].p - taught[i].p - 1;
              if(g !== 2) continue;

              const gapStartP = taught[i].p + 1;
              const slotGap1 = sessionStart + gapStartP;
              const slotGap2 = sessionStart + gapStartP + 1;

              const doubleBlocks = [];
              this.activities.forEach(act => {
                if(act.duration === 2 && !act.isFixed){
                  const curSlot = this.actPlacement[act.id];
                  if(curSlot >= 0 && curSlot !== slotGap1){
                    doubleBlocks.push({ act, curSlot });
                  }
                }
              });

              this.rng.shuffle(doubleBlocks);

              let blockResolved = false;
              for(const candidate of doubleBlocks.slice(0, 15)){
                const actD = candidate.act;
                const srcSlot = candidate.curSlot;
                const cGridD = this.classGrid.get(actD.classId);
                if(!cGridD) continue;

                if(this.offSlots.has(`${actD.classId}|${slotGap1}`) || this.offSlots.has(`${actD.classId}|${slotGap2}`)) continue;
                if(this.fixedSlots.has(`${actD.classId}|${slotGap1}`) || this.fixedSlots.has(`${actD.classId}|${slotGap2}`)) continue;

                const occ1Id = cGridD[slotGap1];
                const occ2Id = cGridD[slotGap2];

                if(occ1Id === -2 || occ1Id === -3 || occ2Id === -2 || occ2Id === -3) continue;

                if(occ1Id < 0 && occ2Id < 0){
                  // Direct move into empty double slot
                  this.unplaceActivity(actD.id);
                  const r1 = this.getConflictsForSlot(actD, slotGap1);
                  if(r1.possible && r1.conflicts.length === 0){
                    this.placeActivityDirect(actD.id, slotGap1);
                    if(this.isLessonBlockSafe(actD) && this.isLessonBlockSafe()){
                      const m = this.evaluateMetrics();
                      if(this.compareMetrics(m, currentBest, "optimize_gap2") < 0){
                        currentBest = { ...m };
                        anyImproved = true;
                        blockResolved = true;
                        if(typeof onProgress === "function") onProgress(currentBest);
                        break;
                      }
                    }
                    this.unplaceActivity(actD.id);
                  }
                  this.placeActivityDirect(actD.id, srcSlot);
                }else if(occ1Id >= 0 && occ2Id >= 0 && occ1Id === occ2Id){
                  // Swap with another 2-period block
                  const actOcc = this.activities[occ1Id];
                  if(!actOcc || actOcc.isFixed || actOcc.duration !== 2) continue;

                  this.unplaceActivity(actD.id);
                  this.unplaceActivity(actOcc.id);

                  const r1 = this.getConflictsForSlot(actD, slotGap1);
                  const r2 = this.getConflictsForSlot(actOcc, srcSlot);

                  if(r1.possible && r1.conflicts.length === 0 && r2.possible && r2.conflicts.length === 0){
                    this.placeActivityDirect(actD.id, slotGap1);
                    this.placeActivityDirect(actOcc.id, srcSlot);

                    if(this.isLessonBlockSafe(actD, actOcc) && this.isLessonBlockSafe()){
                      const m = this.evaluateMetrics();
                      if(this.compareMetrics(m, currentBest, "optimize_gap2") < 0){
                        currentBest = { ...m };
                        anyImproved = true;
                        blockResolved = true;
                        if(typeof onProgress === "function") onProgress(currentBest);
                        break;
                      }
                    }
                    this.unplaceActivity(actD.id);
                    this.unplaceActivity(actOcc.id);
                  }
                  this.placeActivityDirect(actD.id, srcSlot);
                  this.placeActivityDirect(actOcc.id, slotGap1);
                }
                if(blockResolved) break;
              }
              if(blockResolved) break;
            }
          }
        }
      }
      return anyImproved ? currentBest : null;
    }

    // Residual 2-Period Gap Classifier (Spec: ANTIGRAVITY_KHU_2_TIET_TRONG.md De Xuat 6)
    getResidualGap2Sessions(){
      const residuals = [];
      this.teacherGrid.forEach((grid, tKey) => {
        if(!tKey) return;
        for(let d = 0; d < DAYS_LIST.length; d++){
          for(let b = 0; b < SESSIONS_LIST.length; b++){
            const sStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
            const taught = [];
            for(let p = 0; p < PERIODS_PER_SESSION; p++){
              const s = sStart + p;
              if(grid[s] >= 0 || grid[s] === -3) taught.push({ slot: s, p, actId: grid[s] });
            }
            if(taught.length < 2) continue;
            const span = taught[taught.length - 1].p - taught[0].p + 1;
            if(span - taught.length < 2) continue;

            const movable = taught.filter(t => t.actId >= 0 && !this.activities[t.actId].isFixed && this.activities[t.actId].duration === 1);
            let reason = "algorithm-not-yet-resolved";
            if(movable.length === 0) reason = "duration-locked";
            else {
              const classIds = taught.map(t => t.actId >= 0 ? this.activities[t.actId]?.classId : null).filter(Boolean);
              if(classIds.some(cid => this.offSlots.has(`${cid}|${sStart}`))) reason = "class-fixed-halfday-shift";
            }
            residuals.push({ teacher: tKey, day: DAYS_LIST[d], session: SESSIONS_LIST[b], reason });
          }
        }
      });
      return residuals;
    }

    // Standardized Multi-Objective Metric Comparator (Mode-Aware Pareto Optimization)
    compareMetrics(a, b, mode = "optimize_singletons"){
      if(!a) return 1;
      if(!b) return -1;

      if(mode === "optimize_singletons"){
        if(a.soBuoiDay1 !== b.soBuoiDay1) return a.soBuoiDay1 - b.soBuoiDay1;
        if(a.tsBuoiDay !== b.tsBuoiDay) return a.tsBuoiDay - b.tsBuoiDay;
        return a.tsNgayDay - b.tsNgayDay;
      }

      if(mode === "optimize_sessions"){
        if(a.soBuoiDay1 !== b.soBuoiDay1) return a.soBuoiDay1 - b.soBuoiDay1;
        if(a.tsBuoiDay !== b.tsBuoiDay) return a.tsBuoiDay - b.tsBuoiDay;
        const a23 = (a.soBuoiDay2 || 0) * 2 + (a.soBuoiDay3 || 0);
        const b23 = (b.soBuoiDay2 || 0) * 2 + (b.soBuoiDay3 || 0);
        if(a23 !== b23) return a23 - b23;
        return a.tsNgayDay - b.tsNgayDay;
      }

      if(mode === "optimize_gap2"){
        if(a.soBuoiDay1 !== b.soBuoiDay1) return a.soBuoiDay1 - b.soBuoiDay1;

        const budget = this.gap2SessionBudget || 0;
        const baseTs = this.initialMetricsSnapshot?.tsBuoiDay || 0;
        if(baseTs > 0){
          const aOver = a.tsBuoiDay > (baseTs + budget);
          const bOver = b.tsBuoiDay > (baseTs + budget);
          if(aOver !== bOver) return aOver ? 1 : -1;
        }

        if(a.soBuoiTrong2 !== b.soBuoiTrong2) return a.soBuoiTrong2 - b.soBuoiTrong2;
        if(a.tsBuoiDay !== b.tsBuoiDay) return a.tsBuoiDay - b.tsBuoiDay;
        return a.tsNgayDay - b.tsNgayDay;
      }

      if(mode === "optimize_gap1"){
        if(a.soBuoiDay1 !== b.soBuoiDay1) return a.soBuoiDay1 - b.soBuoiDay1;
        if(a.tsBuoiDay !== b.tsBuoiDay) return a.tsBuoiDay - b.tsBuoiDay;
        if(a.soBuoiTrong2 !== b.soBuoiTrong2) return a.soBuoiTrong2 - b.soBuoiTrong2;
        return a.soBuoiTrong1 - b.soBuoiTrong1;
      }

      return (a.soBuoiDay1 - b.soBuoiDay1) || (a.soBuoiTrong2 - b.soBuoiTrong2) || (a.tsBuoiDay - b.tsBuoiDay);
    }

    // Incremental Single-Teacher Evaluation (ANTIGRAVITY_KHU_1_TIET_BUOI.md Section 4.4)
    evaluateTeacherMetrics(tKey){
      const grid = this.teacherGrid.get(tKey);
      if(!grid) return { soNgayMotTiet: 0, soBuoiDay1: 0, soBuoiDay2: 0, soBuoiDay3: 0, tsBuoiDay: 0, tsNgayDay: 0, soBuoiTrong1: 0, soBuoiTrong2: 0 };

      let soNgayMotTiet = 0;
      let soBuoiDay1 = 0;
      let soBuoiDay2 = 0;
      let soBuoiDay3 = 0;
      let tsBuoiDay = 0;
      let tsNgayDay = 0;
      let soBuoiTrong1 = 0;
      let soBuoiTrong2 = 0;

      for(let d = 0; d < DAYS_LIST.length; d++){
        let dayTotal = 0;
        for(let b = 0; b < SESSIONS_LIST.length; b++){
          const sessionStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
          const taughtIndices = [];
          for(let p = 0; p < PERIODS_PER_SESSION; p++){
            const cell = grid[sessionStart + p];
            if(cell >= 0 || cell === -3) taughtIndices.push(p);
          }
          const k = taughtIndices.length;
          dayTotal += k;
          if(k > 0){
            tsBuoiDay++;
            if(k === 1) soBuoiDay1++;
            else if(k === 2) soBuoiDay2++;
            else if(k === 3) soBuoiDay3++;
            const span = taughtIndices[k - 1] - taughtIndices[0] + 1;
            const gaps = span - k;
            if(gaps === 1) soBuoiTrong1++;
            else if(gaps >= 2) soBuoiTrong2++;
          }
        }
        if(dayTotal > 0) tsNgayDay++;
        if(dayTotal === 1) soNgayMotTiet++;
      }
      return { soNgayMotTiet, soBuoiDay1, soBuoiDay2, soBuoiDay3, tsBuoiDay, tsNgayDay, soBuoiTrong1, soBuoiTrong2 };
    }

    // Transparent Residual Singleton Classification (ANTIGRAVITY_KHU_1_TIET_BUOI.md Section 5.5)
    getResidualSingletons(){
      const residuals = [];
      const DAYS = DAYS_LIST;
      const SESSIONS = SESSIONS_LIST;

      this.teacherGrid.forEach((grid, tKey) => {
        if(!tKey) return;
        let totalWeeklyPeriods = 0;
        for(let s = 0; s < TOTAL_SLOTS; s++){
          if(grid[s] >= 0 || grid[s] === -3) totalWeeklyPeriods++;
        }

        for(let d = 0; d < DAYS.length; d++){
          for(let b = 0; b < SESSIONS.length; b++){
            const sStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
            const taught = [];
            for(let p = 0; p < PERIODS_PER_SESSION; p++){
              const s = sStart + p;
              if(grid[s] >= 0 || grid[s] === -3){
                taught.push({ slot: s, p, actId: grid[s] });
              }
            }
            if(taught.length === 1){
              const item = taught[0];
              const act = item.actId >= 0 ? this.activities[item.actId] : null;
              let reason = "constrained-schedule-density";
              if(totalWeeklyPeriods === 1){
                reason = "teacher-only-1-period-total-in-week";
              }
              residuals.push({
                teacher: tKey,
                day: DAYS[d],
                session: SESSIONS[b],
                classId: act ? act.classId : "FIXED",
                mon: act ? act.mon : "FIXED",
                totalWeeklyPeriods,
                reason
              });
            }
          }
        }
      });
      return residuals;
    }

    // LNS Ruin-and-Recreate Perturbation (ANTIGRAVITY_KHU_1_TIET_BUOI.md Section 4.2)
    tryLnsRuinAndRecreate(targetTeacherKeys, bestMetrics, mode = "optimize_singletons", maxGap2Limit = Infinity, onProgress = null){
      const snapPlacement = this.actPlacement.slice();
      const snapClass = new Map();
      this.classGrid.forEach((arr, cid) => snapClass.set(cid, arr.slice()));
      const snapTeacher = new Map();
      this.teacherGrid.forEach((arr, gv) => snapTeacher.set(gv, arr.slice()));
      const snapRoom = new Map();
      this.roomGrid.forEach((arr, rm) => snapRoom.set(rm, arr.slice()));

      const unplacedActs = [];
      for(const tKey of targetTeacherKeys){
        const tGrid = this.teacherGrid.get(tKey);
        if(!tGrid) continue;

        for(let s = 0; s < TOTAL_SLOTS; s++){
          const actId = tGrid[s];
          if(actId >= 0){
            const act = this.activities[actId];
            if(act && !act.isFixed && act.duration === 1){
              this.unplaceActivity(act.id);
              unplacedActs.push(act);
            }
          }
        }
      }

      if(unplacedActs.length === 0) return null;

      // Sort unplaced acts by most-constrained first
      unplacedActs.sort((a, b) => {
        const cA = this.classGrid.get(a.classId)?.filter(x => x === -1).length || 0;
        const cB = this.classGrid.get(b.classId)?.filter(x => x === -1).length || 0;
        return cA - cB;
      });

      // Re-place activities using penalty-guided randomSwap
      let allPlaced = true;
      this.limitCalls = 6000;

      for(const act of unplacedActs){
        this.nCalls = 0;
        const ok = this.randomSwap(act.id, 0);
        if(!ok){
          allPlaced = false;
          break;
        }
      }

      if(allPlaced && this.isLessonBlockSafe()){
        const m = this.evaluateMetrics();
        if(this.compareMetrics(m, bestMetrics, mode) < 0){
          if(typeof onProgress === "function") onProgress(m);
          return m;
        }
      }

      // Rollback
      this.actPlacement = snapPlacement;
      this.classGrid = snapClass;
      this.teacherGrid = snapTeacher;
      this.roomGrid = snapRoom;
      return null;
    }

    // Direction 1: Whole-Session Block Swapping (Hoán đổi toàn bộ khối buổi của lớp - tối ưu tốc độ)
    tryWholeSessionSwap(bestMetrics, mode = "optimize_singletons", onProgress = null){
      const DAYS = DAYS_LIST.length;
      const SESSIONS = SESSIONS_LIST.length;
      const PERIODS = PERIODS_PER_SESSION;
      let currentBest = { ...bestMetrics };
      let anyImproved = false;

      const classList = Array.from(this.classGrid.keys()).filter(Boolean);
      this.rng.shuffle(classList);
      const sampledClasses = classList.slice(0, 12);

      for(const cid of sampledClasses){
        const cGrid = this.classGrid.get(cid);
        if(!cGrid) continue;

        for(let b = 0; b < SESSIONS; b++){
          for(let d1 = 0; d1 < DAYS; d1++){
            const sStart1 = d1 * 10 + b * 5;
            let canSwap1 = true;
            const acts1 = [];
            for(let p = 0; p < PERIODS; p++){
              const s = sStart1 + p;
              if(this.offSlots.has(`${cid}|${s}`)){ canSwap1 = false; break; }
              const actId = cGrid[s];
              if(actId === -3){ canSwap1 = false; break; }
              if(actId >= 0){
                const act = this.activities[actId];
                if(!act || act.isFixed){ canSwap1 = false; break; }
                acts1.push({ slot: s, act, p });
              }
            }
            if(!canSwap1) continue;

            for(let d2 = d1 + 1; d2 < DAYS; d2++){
              const sStart2 = d2 * 10 + b * 5;
              let canSwap2 = true;
              const acts2 = [];
              for(let p = 0; p < PERIODS; p++){
                const s = sStart2 + p;
                if(this.offSlots.has(`${cid}|${s}`)){ canSwap2 = false; break; }
                const actId = cGrid[s];
                if(actId === -3){ canSwap2 = false; break; }
                if(actId >= 0){
                  const act = this.activities[actId];
                  if(!act || act.isFixed){ canSwap2 = false; break; }
                  acts2.push({ slot: s, act, p });
                }
              }
              if(!canSwap2) continue;

              // Unplace all activities in both sessions
              acts1.forEach(item => this.unplaceActivity(item.act.id));
              acts2.forEach(item => this.unplaceActivity(item.act.id));

              let allValid = true;
              for(const item of acts1){
                const targetSlot = sStart2 + item.p;
                const r = this.getConflictsForSlot(item.act, targetSlot);
                if(!r.possible || r.conflicts.length > 0){ allValid = false; break; }
                this.placeActivityDirect(item.act.id, targetSlot);
              }

              if(allValid){
                for(const item of acts2){
                  const targetSlot = sStart1 + item.p;
                  const r = this.getConflictsForSlot(item.act, targetSlot);
                  if(!r.possible || r.conflicts.length > 0){ allValid = false; break; }
                  this.placeActivityDirect(item.act.id, targetSlot);
                }
              }

              if(allValid && this.isLessonBlockSafe(...acts1.map(x => x.act), ...acts2.map(x => x.act))){
                const m = this.evaluateMetrics();
                if(this.compareMetrics(m, currentBest, mode) < 0){
                  currentBest = { ...m };
                  anyImproved = true;
                  if(typeof onProgress === "function") onProgress(currentBest);
                  break;
                }
              }

              // Rollback
              acts1.forEach(item => this.unplaceActivity(item.act.id));
              acts2.forEach(item => this.unplaceActivity(item.act.id));
              acts1.forEach(item => this.placeActivityDirect(item.act.id, item.slot));
              acts2.forEach(item => this.placeActivityDirect(item.act.id, item.slot));
            }
            if(anyImproved) break;
          }
          if(anyImproved) break;
        }
        if(anyImproved) break;
      }
      return anyImproved ? currentBest : null;
    }

    // Direction 2: Related-Cluster Ruin & Recreate (Phá bỏ & Tái cấu trúc cụm giáo viên liên đới)
    tryRelatedClusterRuin(targetTeachers, bestMetrics, mode = "optimize_singletons", maxGap2Limit = Infinity, onProgress = null){
      const relatedTeachers = new Set(targetTeachers);
      targetTeachers.forEach(tKey => {
        const grid = this.teacherGrid.get(tKey);
        if(!grid) return;
        for(let s = 0; s < TOTAL_SLOTS; s++){
          const actId = grid[s];
          if(actId >= 0){
            const act = this.activities[actId];
            if(act && act.classId){
              const cGrid = this.classGrid.get(act.classId);
              if(cGrid){
                for(let s2 = 0; s2 < TOTAL_SLOTS; s2++){
                  const a2Id = cGrid[s2];
                  if(a2Id >= 0){
                    const a2 = this.activities[a2Id];
                    if(a2 && a2.gv && a2.duration === 1 && !a2.isFixed){
                      relatedTeachers.add(a2.gv);
                    }
                  }
                }
              }
            }
          }
        }
      });

      const chosen = Array.from(relatedTeachers);
      this.rng.shuffle(chosen);
      const sample = chosen.slice(0, Math.min(3, chosen.length));
      return this.tryLnsRuinAndRecreate(sample, bestMetrics, mode, maxGap2Limit, onProgress);
    }

    // Direction 3: Deep 4-Way Ejection Chain (Chuỗi đẩy 4 cấp tối ưu tốc độ)
    tryDeepEjectionChain(targetTeachers, bestMetrics, mode = "optimize_singletons", onProgress = null){
      let currentBest = { ...bestMetrics };
      let anyImproved = false;

      for(const tKey of targetTeachers){
        const grid = this.teacherGrid.get(tKey);
        if(!grid) continue;

        // Find teacher's active slots
        const tSlots = [];
        for(let s = 0; s < TOTAL_SLOTS; s++){
          const aId = grid[s];
          if(aId >= 0){
            const act = this.activities[aId];
            if(act && !act.isFixed && act.duration === 1) tSlots.push({ s, act });
          }
        }

        for(const item1 of tSlots){
          const s1 = item1.s;
          const act1 = item1.act;
          const cGrid1 = this.classGrid.get(act1.classId);
          if(!cGrid1) continue;

          // Step 1: Candidate s2 slots in class 1
          const cand2 = [];
          for(let s2 = 0; s2 < TOTAL_SLOTS; s2++){
            if(s2 === s1 || this.offSlots.has(`${act1.classId}|${s2}`)) continue;
            const a2Id = cGrid1[s2];
            if(a2Id < 0) continue;
            const act2 = this.activities[a2Id];
            if(!act2 || act2.isFixed || act2.duration !== 1) continue;
            const tGrid1 = this.teacherGrid.get(act1.gv);
            if(tGrid1 && tGrid1[s2] >= 0 && tGrid1[s2] !== act1.id) continue;
            cand2.push({ s2, act2 });
            if(cand2.length >= 3) break;
          }

          for(const item2 of cand2){
            const s2 = item2.s2;
            const act2 = item2.act2;
            const cGrid2 = this.classGrid.get(act2.classId);
            if(!cGrid2) continue;

            // Step 2: Candidate s3 slots in class 2
            const cand3 = [];
            for(let s3 = 0; s3 < TOTAL_SLOTS; s3++){
              if(s3 === s2 || s3 === s1 || this.offSlots.has(`${act2.classId}|${s3}`)) continue;
              const a3Id = cGrid2[s3];
              if(a3Id < 0) continue;
              const act3 = this.activities[a3Id];
              if(!act3 || act3.isFixed || act3.duration !== 1) continue;
              const tGrid2 = this.teacherGrid.get(act2.gv);
              if(tGrid2 && tGrid2[s3] >= 0 && tGrid2[s3] !== act2.id) continue;
              cand3.push({ s3, act3 });
              if(cand3.length >= 3) break;
            }

            for(const item3 of cand3){
              const s3 = item3.s3;
              const act3 = item3.act3;
              const cGrid3 = this.classGrid.get(act3.classId);
              if(!cGrid3) continue;

              // Step 3: Candidate s4 slots in class 3 that can cycle back to s1
              let checked4 = 0;
              for(let s4 = 0; s4 < TOTAL_SLOTS; s4++){
                if(s4 === s3 || s4 === s2 || s4 === s1 || this.offSlots.has(`${act3.classId}|${s4}`)) continue;
                const a4Id = cGrid3[s4];
                if(a4Id < 0) continue;
                const act4 = this.activities[a4Id];
                if(!act4 || act4.isFixed || act4.duration !== 1) continue;
                const tGrid3 = this.teacherGrid.get(act3.gv);
                if(tGrid3 && tGrid3[s4] >= 0 && tGrid3[s4] !== act3.id) continue;
                const tGrid4 = this.teacherGrid.get(act4.gv);
                if(tGrid4 && tGrid4[s1] >= 0 && tGrid4[s1] !== act4.id) continue;

                checked4++;
                if(checked4 > 3) break;

                // Test 4-way cyclic placement
                this.unplaceActivity(act1.id);
                this.unplaceActivity(act2.id);
                this.unplaceActivity(act3.id);
                this.unplaceActivity(act4.id);

                const r1 = this.getConflictsForSlot(act1, s2);
                const r2 = this.getConflictsForSlot(act2, s3);
                const r3 = this.getConflictsForSlot(act3, s4);
                const r4 = this.getConflictsForSlot(act4, s1);

                if(r1.possible && r1.conflicts.length === 0 &&
                   r2.possible && r2.conflicts.length === 0 &&
                   r3.possible && r3.conflicts.length === 0 &&
                   r4.possible && r4.conflicts.length === 0){
                  this.placeActivityDirect(act1.id, s2);
                  this.placeActivityDirect(act2.id, s3);
                  this.placeActivityDirect(act3.id, s4);
                  this.placeActivityDirect(act4.id, s1);

                  if(this.isLessonBlockSafe(act1, act2, act3, act4) && this.isLessonBlockSafe()){
                    const m = this.evaluateMetrics();
                    if(this.compareMetrics(m, currentBest, mode) < 0){
                      currentBest = { ...m };
                      anyImproved = true;
                      if(typeof onProgress === "function") onProgress(currentBest);
                      break;
                    }
                  }
                  this.unplaceActivity(act1.id);
                  this.unplaceActivity(act2.id);
                  this.unplaceActivity(act3.id);
                  this.unplaceActivity(act4.id);
                }
                this.placeActivityDirect(act1.id, s1);
                this.placeActivityDirect(act2.id, s2);
                this.placeActivityDirect(act3.id, s3);
                this.placeActivityDirect(act4.id, s4);
              }
              if(anyImproved) break;
            }
            if(anyImproved) break;
          }
          if(anyImproved) break;
        }
        if(anyImproved) break;
      }
      return anyImproved ? currentBest : null;
    }

    // Direction 4: Neutral Plateau Random Walk (Bước đi ngang vượt qua yên ngựa)
    tryNeutralPlateauWalk(steps = 8, bestMetrics, mode = "optimize_singletons", onProgress = null){
      const snapPlacement = this.actPlacement.slice();
      const snapClass = new Map();
      this.classGrid.forEach((arr, cid) => snapClass.set(cid, arr.slice()));
      const snapTeacher = new Map();
      this.teacherGrid.forEach((arr, gv) => snapTeacher.set(gv, arr.slice()));
      const snapRoom = new Map();
      this.roomGrid.forEach((arr, rm) => snapRoom.set(rm, arr.slice()));

      let currentBest = { ...bestMetrics };
      let anyImproved = false;

      for(let step = 0; step < steps; step++){
        const actList = this.activities.filter(a => a.duration === 1 && !a.isFixed && this.actPlacement[a.id] >= 0);
        if(actList.length === 0) break;
        const act1 = actList[Math.floor(this.rng.next() * actList.length)];
        const s1 = this.actPlacement[act1.id];
        const cGrid1 = this.classGrid.get(act1.classId);
        if(!cGrid1) continue;

        const s2 = Math.floor(this.rng.next() * 60);
        if(s2 === s1 || this.offSlots.has(`${act1.classId}|${s2}`)) continue;

        const a2Id = cGrid1[s2];
        if(a2Id === -2 || a2Id === -3 || this.fixedSlots.has(`${act1.classId}|${s2}`)) continue;

        if(a2Id < 0){
          this.unplaceActivity(act1.id);
          const r = this.getConflictsForSlot(act1, s2);
          if(r.possible && r.conflicts.length === 0){
            this.placeActivityDirect(act1.id, s2);
            if(this.isLessonBlockSafe(act1)){
              const m = this.evaluateMetrics();
              const comp = this.compareMetrics(m, currentBest, mode);
              if(comp < 0 && this.isLessonBlockSafe()){
                currentBest = { ...m };
                anyImproved = true;
                if(typeof onProgress === "function") onProgress(currentBest);
                break;
              }else if(comp === 0 && this.isLessonBlockSafe(act1)){
                continue; // Keep valid neutral move to traverse plateau
              }
            }
            this.unplaceActivity(act1.id);
          }
          this.placeActivityDirect(act1.id, s1);
        }else{
          const act2 = this.activities[a2Id];
          if(!act2 || act2.isFixed || act2.duration !== 1 || this.fixedSlots.has(`${act2.classId}|${s1}`)) continue;
          this.unplaceActivity(act1.id);
          this.unplaceActivity(act2.id);

          const r1 = this.getConflictsForSlot(act1, s2);
          const r2 = this.getConflictsForSlot(act2, s1);
          if(r1.possible && r1.conflicts.length === 0 && r2.possible && r2.conflicts.length === 0){
            this.placeActivityDirect(act1.id, s2);
            this.placeActivityDirect(act2.id, s1);
            if(this.isLessonBlockSafe(act1, act2)){
              const m = this.evaluateMetrics();
              const comp = this.compareMetrics(m, currentBest, mode);
              if(comp < 0 && this.isLessonBlockSafe()){
                currentBest = { ...m };
                anyImproved = true;
                if(typeof onProgress === "function") onProgress(currentBest);
                break;
              }else if(comp === 0 && this.isLessonBlockSafe(act1, act2)){
                continue; // Keep valid neutral move to traverse plateau
              }
            }
            this.unplaceActivity(act1.id);
            this.unplaceActivity(act2.id);
          }
          this.placeActivityDirect(act1.id, s1);
          this.placeActivityDirect(act2.id, s2);
        }
      }

      if(!anyImproved){
        this.actPlacement = snapPlacement;
        this.classGrid = snapClass;
        this.teacherGrid = snapTeacher;
        this.roomGrid = snapRoom;
        return null;
      }
      return currentBest;
    }

    // Powerful, time-budgeted asynchronous multi-pass optimizer with Multi-Directional Escape Architecture
    async optimize(mode = "optimize_singletons", progressCallback = null){
      this.loadExistingSchedule();
      const initialMetrics = this.evaluateMetrics();
      this.initialMetricsSnapshot = { ...initialMetrics };
      let bestMetrics = { ...initialMetrics };
      let bestPlacement = this.actPlacement.slice();
      let bestClassGrid = new Map();
      this.classGrid.forEach((arr, cid) => bestClassGrid.set(cid, arr.slice()));
      let bestTeacherGrid = new Map();
      this.teacherGrid.forEach((arr, gv) => bestTeacherGrid.set(gv, arr.slice()));
      let bestRoomGrid = new Map();
      this.roomGrid.forEach((arr, rm) => bestRoomGrid.set(rm, arr.slice()));

      // Elite archive of diverse promising configurations
      const eliteArchive = [{
        metrics: { ...initialMetrics },
        placement: this.actPlacement.slice(),
        classGrid: new Map(Array.from(this.classGrid.entries()).map(([k, v]) => [k, v.slice()])),
        teacherGrid: new Map(Array.from(this.teacherGrid.entries()).map(([k, v]) => [k, v.slice()])),
        roomGrid: new Map(Array.from(this.roomGrid.entries()).map(([k, v]) => [k, v.slice()]))
      }];

      const saveBestSnapshot = () => {
        bestPlacement = this.actPlacement.slice();
        bestClassGrid = new Map();
        this.classGrid.forEach((arr, cid) => bestClassGrid.set(cid, arr.slice()));
        bestTeacherGrid = new Map();
        this.teacherGrid.forEach((arr, gv) => bestTeacherGrid.set(gv, arr.slice()));
        bestRoomGrid = new Map();
        this.roomGrid.forEach((arr, rm) => bestRoomGrid.set(rm, arr.slice()));

        // Keep up to 3 elite snapshots
        if(eliteArchive.length < 3 || this.compareMetrics(bestMetrics, eliteArchive[0].metrics, mode) < 0){
          eliteArchive.unshift({
            metrics: { ...bestMetrics },
            placement: bestPlacement.slice(),
            classGrid: new Map(Array.from(bestClassGrid.entries()).map(([k, v]) => [k, v.slice()])),
            teacherGrid: new Map(Array.from(bestTeacherGrid.entries()).map(([k, v]) => [k, v.slice()])),
            roomGrid: new Map(Array.from(bestRoomGrid.entries()).map(([k, v]) => [k, v.slice()]))
          });
          if(eliteArchive.length > 3) eliteArchive.pop();
        }
      };

      const getMetricVal = (m) => {
        if(mode === "optimize_singletons") return m.soBuoiDay1;
        if(mode === "optimize_sessions") return m.tsBuoiDay;
        if(mode === "optimize_gap2") return m.soBuoiTrong2;
        if(mode === "optimize_gap1") return m.soBuoiTrong1;
        return m.soBuoiDay1;
      };

      const notifyLiveProgress = (metrics) => {
        const currentVal = getMetricVal(metrics);
        const initialVal = getMetricVal(initialMetrics);
        const pct = Math.min(99, Math.round(((round + 1) / MAX_ROUNDS) * 100));
        if(progressCallback){
          progressCallback({
            percent: pct,
            currentMetric: currentVal,
            initialMetric: initialVal,
            metrics: metrics
          });
        }
      };

      if(progressCallback){
        progressCallback({
          percent: 0,
          currentMetric: getMetricVal(bestMetrics),
          initialMetric: getMetricVal(initialMetrics),
          metrics: bestMetrics
        });
      }

      const MAX_ROUNDS = (mode === "optimize_singletons") ? 65 : ((mode === "optimize_gap2") ? 45 : 55);
      let consecutiveUnimprovedRounds = 0;
      const maxStagnantRounds = (mode === "optimize_singletons") ? 25 : 18;
      let destroyStrength = 1;
      let round = 0;

      for(round = 0; round < MAX_ROUNDS; round++){
        if(typeof window !== "undefined" && window.__AUTO_SORT_STOP_REQUESTED) break;

        let improvedInRound = false;
        await new Promise(resolve => setTimeout(resolve, 25)); // Give UI thread smooth breathing room

        // 1. Primary Downhill Optimization Passes
        if(mode === "optimize_singletons"){
          const oblitM = this.obliterateAllTeacherSingletons(12, Infinity, notifyLiveProgress);
          if(oblitM && this.compareMetrics(oblitM, bestMetrics, mode) < 0){
            bestMetrics = { ...oblitM };
            saveBestSnapshot();
            improvedInRound = true;
            destroyStrength = 1;
          }

          const resReinforce = this.tryReinforceTeacherSingletons(bestMetrics, initialMetrics, Infinity, notifyLiveProgress);
          if(resReinforce && this.compareMetrics(resReinforce, bestMetrics, mode) < 0){
            bestMetrics = { ...resReinforce };
            saveBestSnapshot();
            improvedInRound = true;
            destroyStrength = 1;
          }

          const resSingle = this.tryConsolidateTeacherSingletons(bestMetrics, initialMetrics, Infinity, notifyLiveProgress);
          if(resSingle && this.compareMetrics(resSingle, bestMetrics, mode) < 0){
            bestMetrics = { ...resSingle };
            saveBestSnapshot();
            improvedInRound = true;
            destroyStrength = 1;
          }
        }

        if(mode === "optimize_sessions"){
          const resVacate = this.tryVacateTeacherSessions(bestMetrics, initialMetrics, Infinity, notifyLiveProgress);
          if(resVacate && this.compareMetrics(resVacate, bestMetrics, mode) < 0){
            bestMetrics = { ...resVacate };
            saveBestSnapshot();
            improvedInRound = true;
          }

          const thinSessions = [];
          this.teacherGrid.forEach((tGrid, tKey) => {
            if(!tKey) return;
            for(let d = 0; d < DAYS_LIST.length; d++){
              for(let b = 0; b < SESSIONS_LIST.length; b++){
                const sStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
                let cnt = 0;
                for(let p = 0; p < PERIODS_PER_SESSION; p++){
                  if(tGrid[sStart + p] >= 0 || tGrid[sStart + p] === -3) cnt++;
                }
                if(cnt === 1 || cnt === 2) thinSessions.push({ tKey, d, b, cnt });
              }
            }
          });
          this.rng.shuffle(thinSessions);
          thinSessions.sort((x, y) => x.cnt - y.cnt);

          for(const s of thinSessions.slice(0, 30)){
            const res = this.tryVacateTeacherSession(s.tKey, s.d, s.b, bestMetrics, initialMetrics);
            if(res && this.compareMetrics(res, bestMetrics, mode) < 0){
              bestMetrics = { ...res };
              saveBestSnapshot();
              improvedInRound = true;
              break;
            }
          }

          const oblitThin = this.obliterateAllThinTeacherSessions(8, [1, 2], Infinity, notifyLiveProgress);
          if(oblitThin && this.compareMetrics(oblitThin, bestMetrics, mode) < 0){
            bestMetrics = { ...oblitThin };
            saveBestSnapshot();
            improvedInRound = true;
          }

          const oblitM = this.obliterateAllTeacherSingletons(8, Infinity, notifyLiveProgress);
          if(oblitM && this.compareMetrics(oblitM, bestMetrics, mode) < 0){
            bestMetrics = { ...oblitM };
            saveBestSnapshot();
            improvedInRound = true;
          }

          const resSingle = this.tryConsolidateTeacherSingletons(bestMetrics, initialMetrics, Infinity, notifyLiveProgress);
          if(resSingle && this.compareMetrics(resSingle, bestMetrics, mode) < 0){
            bestMetrics = { ...resSingle };
            saveBestSnapshot();
            improvedInRound = true;
          }
        }

        if(mode === "optimize_gap2"){
          // Enable controlled session budget in the second half of rounds if stagnant (Spec: ANTIGRAVITY_KHU_2_TIET_TRONG.md De Xuat 2)
          if(round >= Math.floor(MAX_ROUNDS * 0.65)){
            this.gap2SessionBudget = this.options.gap2SessionBudget || 2;
          }else{
            this.gap2SessionBudget = 0;
          }

          // 1. Forward Gap Crusher
          const resGap = this.tryCrushTeacherGaps(bestMetrics, initialMetrics, "optimize_gap2", notifyLiveProgress);
          if(resGap && this.compareMetrics(resGap, bestMetrics, mode) < 0){
            bestMetrics = { ...resGap };
            saveBestSnapshot();
            improvedInRound = true;
          }

          // 2. Inbound Gap-Filler (De Xuat 3)
          const resFill = this.tryFillTeacherGapFromElsewhere(bestMetrics, initialMetrics, notifyLiveProgress);
          if(resFill && this.compareMetrics(resFill, bestMetrics, mode) < 0){
            bestMetrics = { ...resFill };
            saveBestSnapshot();
            improvedInRound = true;
          }

          // 3. Double Block Gap-Filler (De Xuat 4)
          const resDouble = this.tryMoveDoubleBlockIntoGap(bestMetrics, initialMetrics, notifyLiveProgress);
          if(resDouble && this.compareMetrics(resDouble, bestMetrics, mode) < 0){
            bestMetrics = { ...resDouble };
            saveBestSnapshot();
            improvedInRound = true;
          }

          // 4. Expanded Vacate on sessions with hasGap2 (De Xuat 1 + 5: bo idx.length <= 2, tang mau len 15-20 GV)
          const gapTeachers = [];
          this.teacherGrid.forEach((grid, tKey) => {
            if(!tKey) return;
            const tm = this.evaluateTeacherMetrics(tKey);
            if(tm.soBuoiTrong2 > 0) gapTeachers.push(tKey);
          });
          if(gapTeachers.length > 0){
            this.rng.shuffle(gapTeachers);
            for(const tKey of gapTeachers.slice(0, 15)){
              for(let d = 0; d < DAYS_LIST.length; d++){
                for(let b = 0; b < SESSIONS_LIST.length; b++){
                  const sStart = d * SLOTS_PER_DAY + b * PERIODS_PER_SESSION;
                  const tGrid = this.teacherGrid.get(tKey);
                  let hasGap2 = false;
                  const idx = [];
                  for(let p = 0; p < PERIODS_PER_SESSION; p++){
                    if(tGrid[sStart + p] >= 0 || tGrid[sStart + p] === -3) idx.push(p);
                  }
                  for(let i = 0; i < idx.length - 1; i++){
                    if(idx[i + 1] - idx[i] - 1 >= 2) hasGap2 = true;
                  }
                  if(hasGap2){
                    const resV = this.tryVacateTeacherSession(tKey, d, b, bestMetrics, initialMetrics, mode);
                    if(resV && this.compareMetrics(resV, bestMetrics, mode) < 0){
                      bestMetrics = { ...resV };
                      saveBestSnapshot();
                      improvedInRound = true;
                      break;
                    }
                  }
                }
                if(improvedInRound) break;
              }
              if(improvedInRound) break;
            }
          }
        }

        if(mode === "optimize_gap1"){
          const resGap = this.tryCrushTeacherGaps(bestMetrics, initialMetrics, "optimize_gap1", notifyLiveProgress);
          if(resGap && this.compareMetrics(resGap, bestMetrics, mode) < 0){
            bestMetrics = { ...resGap };
            saveBestSnapshot();
            improvedInRound = true;
          }
        }

        // =========================================================================
        // 2. MULTI-DIRECTIONAL ESCAPE ARCHITECTURE (KHI BỊ ĐỨNG / STAGNATION ESCAPE)
        // =========================================================================
        if(!improvedInRound){
          consecutiveUnimprovedRounds++;

          // Identify current bottleneck teachers
          const bottleneckTeachers = [];
          this.teacherGrid.forEach((grid, tKey) => {
            if(!tKey) return;
            const tm = this.evaluateTeacherMetrics(tKey);
            if((mode === "optimize_singletons" && tm.soBuoiDay1 > 0) ||
               (mode === "optimize_sessions" && (tm.tsBuoiDay >= 4 || tm.soBuoiDay2 > 0 || tm.soBuoiDay3 > 0)) ||
               (mode === "optimize_gap2" && tm.soBuoiTrong2 > 0) ||
               (mode === "optimize_gap1" && tm.soBuoiTrong1 > 0)){
              bottleneckTeachers.push(tKey);
            }
          });
          this.rng.shuffle(bottleneckTeachers);

          // ESCAPE DIRECTION A: Whole-Session Block Swaps (Hoán đổi cụm buổi của lớp)
          if(consecutiveUnimprovedRounds % 4 === 1){
            const resBlock = this.tryWholeSessionSwap(bestMetrics, mode, notifyLiveProgress);
            if(resBlock && this.compareMetrics(resBlock, bestMetrics, mode) < 0){
              bestMetrics = { ...resBlock };
              saveBestSnapshot();
              improvedInRound = true;
              consecutiveUnimprovedRounds = 0;
            }
          }

          // ESCAPE DIRECTION B: Deep 4-Way Ejection Chains (Chuỗi đẩy liên hoàn 4 cấp)
          if(!improvedInRound && (consecutiveUnimprovedRounds % 4 === 2 || consecutiveUnimprovedRounds >= 5)){
            if(bottleneckTeachers.length > 0){
              const resChain = this.tryDeepEjectionChain(bottleneckTeachers.slice(0, 5), bestMetrics, mode, notifyLiveProgress);
              if(resChain && this.compareMetrics(resChain, bestMetrics, mode) < 0){
                bestMetrics = { ...resChain };
                saveBestSnapshot();
                improvedInRound = true;
                consecutiveUnimprovedRounds = 0;
              }
            }
          }

          // ESCAPE DIRECTION C: Related-Cluster Ruin & Recreate (Phá bỏ & Tái cấu trúc cụm liên đới)
          if(!improvedInRound && (consecutiveUnimprovedRounds % 4 === 3 || consecutiveUnimprovedRounds >= 6)){
            if(bottleneckTeachers.length > 0){
              const resCluster = this.tryRelatedClusterRuin(bottleneckTeachers.slice(0, 4), bestMetrics, mode, Infinity, notifyLiveProgress);
              if(resCluster && this.compareMetrics(resCluster, bestMetrics, mode) < 0){
                bestMetrics = { ...resCluster };
                saveBestSnapshot();
                improvedInRound = true;
                consecutiveUnimprovedRounds = 0;
              }
            }
          }

          // ESCAPE DIRECTION D: Neutral Plateau Random Walk (Bước đi ngang trên yên ngựa)
          if(!improvedInRound && consecutiveUnimprovedRounds >= 4 && consecutiveUnimprovedRounds % 3 === 0){
            const resWalk = this.tryNeutralPlateauWalk(12, bestMetrics, mode, notifyLiveProgress);
            if(resWalk && this.compareMetrics(resWalk, bestMetrics, mode) < 0){
              bestMetrics = { ...resWalk };
              saveBestSnapshot();
              improvedInRound = true;
              consecutiveUnimprovedRounds = 0;
            }
          }

          // ESCAPE DIRECTION E: Elite Archive Branching (Đổi sang nhánh tinh hoa khác khi bế tắc sâu)
          if(!improvedInRound && consecutiveUnimprovedRounds >= 10 && eliteArchive.length > 1){
            const altElite = eliteArchive[Math.floor(this.rng.next() * eliteArchive.length)];
            if(altElite){
              this.actPlacement = altElite.placement.slice();
              this.classGrid = new Map(Array.from(altElite.classGrid.entries()).map(([k, v]) => [k, v.slice()]));
              this.teacherGrid = new Map(Array.from(altElite.teacherGrid.entries()).map(([k, v]) => [k, v.slice()]));
              this.roomGrid = new Map(Array.from(altElite.roomGrid.entries()).map(([k, v]) => [k, v.slice()]));
              this.tryNeutralPlateauWalk(8, bestMetrics, mode, notifyLiveProgress);
            }
          }
        }else{
          consecutiveUnimprovedRounds = 0;
        }

        const pct = Math.min(99, Math.round(((round + 1) / MAX_ROUNDS) * 100));
        if(progressCallback){
          progressCallback({
            percent: pct,
            currentMetric: getMetricVal(bestMetrics),
            initialMetric: getMetricVal(initialMetrics),
            metrics: bestMetrics
          });
        }

        if(mode === "optimize_singletons" && bestMetrics.soBuoiDay1 <= 2){
          if(progressCallback){
            progressCallback({
              percent: 100,
              currentMetric: bestMetrics.soBuoiDay1,
              initialMetric: Math.max(1, getMetricVal(initialMetrics)),
              metrics: bestMetrics
            });
          }
          break;
        }

        if(getMetricVal(bestMetrics) === 0){
          if(progressCallback){
            progressCallback({
              percent: 100,
              currentMetric: getMetricVal(bestMetrics),
              initialMetric: Math.max(1, getMetricVal(initialMetrics)),
              metrics: bestMetrics
            });
          }
          break;
        }

        if(consecutiveUnimprovedRounds >= maxStagnantRounds){
          if(progressCallback){
            progressCallback({
              percent: 100,
              currentMetric: getMetricVal(bestMetrics),
              initialMetric: Math.max(1, getMetricVal(initialMetrics)),
              metrics: bestMetrics
            });
          }
          break;
        }
      }

      if(bestPlacement){
        this.actPlacement = bestPlacement;
        this.classGrid = bestClassGrid;
        this.teacherGrid = bestTeacherGrid;
        this.roomGrid = bestRoomGrid;
      }

      this.applyToDataTKB();

      let placed = 0;
      this.activities.forEach((act, idx) => {
        if(this.actPlacement[idx] >= 0) placed += act.duration;
      });
      placed += this.fixedSlots.size;

      return {
        ok: true,
        placed,
        unassigned: 0,
        initialMetrics,
        metrics: bestMetrics,
        residualSingletons: this.getResidualSingletons(),
        residualGap2: this.getResidualGap2Sessions()
      };
    }
  }

  global.FetTimetableEngine = FetTimetableEngine;

})(typeof window !== "undefined" ? window : globalThis);

