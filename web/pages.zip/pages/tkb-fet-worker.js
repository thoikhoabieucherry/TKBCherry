/**
 * TKB FET Background Worker
 * Runs FetTimetableEngine on a dedicated background CPU thread
 * Guarantees 60 FPS smooth UI and instant cancellation
 */

// Import the FET engine into worker scope with cache buster
importScripts('tkb-fet-engine.js?v=' + Date.now());

let currentEngine = null;

self.onmessage = async function(e) {
  const action = e.data?.action || e.data?.type;
  const { mode, data, options } = e.data || {};

  if (action === 'optimize') {
    try {
      currentEngine = new self.FetTimetableEngine(data, options);
      
      const res = await currentEngine.optimize(mode, (prog) => {
        let snapshotTkb = null;
        try { snapshotTkb = currentEngine.getSnapshotTKB(); } catch(_) {}
        self.postMessage({
          type: 'progress',
          mode: mode,
          percent: prog.percent,
          currentMetric: prog.currentMetric,
          initialMetric: prog.initialMetric,
          metrics: prog.metrics,
          checkpoint: {
            complete: true,
            tkb: snapshotTkb,
            metrics: prog.metrics
          },
          tkb: snapshotTkb
        });
      });

      self.postMessage({
        type: 'done',
        ok: true,
        applied: true,
        tkb: currentEngine.getSnapshotTKB(),
        initialMetrics: res.initialMetrics,
        metrics: res.metrics,
        placed: res.placed,
        unassigned: res.unassigned
      });
    } catch (err) {
      self.postMessage({
        type: 'error',
        error: err?.message || String(err)
      });
    }
  } else if (action === 'solve') {
    try {
      currentEngine = new self.FetTimetableEngine(data, options);
      const res = currentEngine.solve((prog) => {
        self.postMessage({
          type: 'progress',
          percent: prog.percent,
          placed: prog.placed,
          total: prog.total
        });
      });

      const snapshotTkb = currentEngine.getSnapshotTKB();
      self.postMessage({
        type: 'done',
        ok: true,
        applied: true,
        tkb: snapshotTkb,
        checkpoint: {
          complete: true,
          tkb: snapshotTkb
        },
        placed: res.placed,
        unassigned: res.unassigned,
        total: res.total || (res.placed + res.unassigned)
      });
    } catch (err) {
      self.postMessage({
        type: 'error',
        error: err?.message || String(err)
      });
    }
  }
};
